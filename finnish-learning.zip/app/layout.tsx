import type React from "react"
import "./globals.css"
import { Inter } from "next/font/google"
import Link from "next/link"
import { ThemeProvider } from "@/components/theme-provider"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Suomen kielen oppiminen",
  description: "Opi suomen kielen sanastoa ja ilmaisuja kansainvälisille opiskelijoille",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fi">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light">
          <div className="flex flex-col min-h-screen">
            <header className="bg-blue-600 text-white shadow-lg">
              <div className="container mx-auto px-4 py-4 flex justify-between items-center">
                <Link href="/" className="flex items-center gap-3 hover:opacity-90 transition-opacity">
                  <div className="bg-white rounded-full w-12 h-12 flex items-center justify-center shadow-md">
                    <span className="text-blue-600 text-2xl font-bold">S</span>
                  </div>
                  <span className="text-2xl font-bold">Suomen kielen oppiminen</span>
                </Link>

                <nav className="flex items-center gap-8">
                  <Link href="/" className="hover:text-yellow-300 transition-colors font-medium">
                    Etusivu
                  </Link>
                  <Link href="/learn-finnish" className="hover:text-yellow-300 transition-colors font-medium">
                    Opi suomea
                  </Link>
                  <Link href="/feedback" className="hover:text-yellow-300 transition-colors font-medium">
                    Palautetta
                  </Link>
                </nav>
              </div>
            </header>

            <main className="flex-1">{children}</main>

            <footer className="bg-gray-100 py-8 border-t">
              <div className="container mx-auto px-4 text-center text-gray-600">
                <p className="text-lg">© 2023 Suomen kielen oppimisalusta. Kaikki oikeudet pidätetään.</p>
                <p className="mt-2">Autamme kansainvälisiä opiskelijoita oppimaan suomea askel askeleelta.</p>
              </div>
            </footer>
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}
