"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { BookOpen, Headphones, MessageSquare, CheckSquare, Star, Sparkles, Trophy, Play } from "lucide-react"

export default function LearnFinnish() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const modules = [
    {
      title: "Perussanasto",
      description: "Opi olennaista suomen sanastoa työpaikan taukotiloihin ja kahviloihin",
      icon: BookOpen,
      href: "/modules/basic-vocabulary/intro",
      gradient: "from-blue-500 to-blue-600",
      bgGradient: "from-blue-50 to-blue-100",
      features: [
        "Opi 9 olennaista kahvilan sanastoa",
        "Harjoittele ääntämistä äänioppaiden kanssa",
        "Yhdistä sanat kuviin",
      ],
      delay: "delay-100",
    },
    {
      title: "Kuullun ymmärtäminen",
      description: "Harjoittele suomen kielen ymmärtämistä kahvilaympäristössä",
      icon: Headphones,
      href: "/modules/listening-comprehension/intro",
      gradient: "from-green-500 to-green-600",
      bgGradient: "from-green-50 to-green-100",
      features: ["Kuuntele ohjeita suomeksi", "Tunnista esineitä kahvilakuvassa", "Paranna kuuntelun ymmärtämistä"],
      delay: "delay-200",
    },
    {
      title: "Sana- ja lauseharjoitukset",
      description: "Harjoittele suomen lauseiden muodostamista ja verbien käyttöä",
      icon: MessageSquare,
      href: "/modules/word-practice",
      gradient: "from-purple-500 to-purple-600",
      bgGradient: "from-purple-50 to-purple-100",
      features: [
        "Yhdistä lauseiden alut ja loput",
        "Opi yleisiä suomen verbejä",
        "Harjoittele verbien käyttöä yhteyksissä",
      ],
      delay: "delay-300",
    },
    {
      title: "Kuullun ymmärtämisen testi",
      description: "Testaa suomen ymmärtämistäsi tosi/epätosi -testillä",
      icon: CheckSquare,
      href: "/modules/listening-quiz",
      gradient: "from-orange-500 to-red-500",
      bgGradient: "from-orange-50 to-red-100",
      features: [
        "Kuuntele kuvauksia suomeksi",
        "Määritä, ovatko väittämät tosia vai epätosia",
        "Testaa kokonaisymmärrystäsi",
      ],
      delay: "delay-400",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-purple-800 text-white relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-20 left-20 w-32 h-32 bg-yellow-400/20 rounded-full animate-pulse"></div>
          <div className="absolute top-40 right-32 w-24 h-24 bg-blue-300/30 rounded-full animate-bounce delay-1000"></div>
          <div className="absolute bottom-32 left-1/4 w-16 h-16 bg-purple-400/25 rounded-full animate-ping delay-2000"></div>
        </div>

        <div className="container mx-auto px-4 py-20 relative z-10">
          <div
            className={`text-center transform transition-all duration-1000 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}
          >
            <div className="flex justify-center mb-6">
              <div className="bg-gradient-to-r from-yellow-400 to-orange-400 p-6 rounded-full animate-spin-slow shadow-2xl">
                <Sparkles className="h-12 w-12 text-blue-900" />
              </div>
            </div>

            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-white to-blue-100 bg-clip-text text-transparent">
              Oppimispolku
            </h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto mb-8 leading-relaxed">
              Aloita matkasi suomen kielen oppimiseen! Neljä interaktiivista moduulia vie sinut perusteista
              edistyneempiin taitoihin.
            </p>

            <div className="flex justify-center gap-4 mb-8">
              <div className="flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full">
                <Trophy className="h-5 w-5 text-yellow-400" />
                <span className="text-sm font-medium">4 Moduulia</span>
              </div>
              <div className="flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full">
                <Star className="h-5 w-5 text-yellow-400" />
                <span className="text-sm font-medium">Interaktiivinen oppiminen</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modules Grid */}
      <div className="container mx-auto px-4 py-20">
        <div className="grid gap-12 max-w-6xl mx-auto">
          {modules.map((module, index) => (
            <div
              key={index}
              className={`grid md:grid-cols-2 gap-8 items-center animate-fade-in-up ${module.delay} ${
                index % 2 === 1 ? "md:grid-flow-col-dense" : ""
              }`}
            >
              {/* Content */}
              <div className={`space-y-6 ${index % 2 === 1 ? "md:col-start-2" : ""}`}>
                <div className="flex items-center gap-4 mb-4">
                  <div className={`bg-gradient-to-r ${module.gradient} p-4 rounded-full shadow-xl animate-pulse`}>
                    <module.icon className="h-8 w-8 text-white" />
                  </div>
                  <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-4 py-2 rounded-full text-sm font-semibold">
                    Moduuli {index + 1}
                  </div>
                </div>

                <h2 className="text-3xl font-bold text-gray-800 mb-4">{module.title}</h2>
                <p className="text-gray-600 text-lg leading-relaxed mb-6">{module.description}</p>

                <ul className="space-y-3 mb-8">
                  {module.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full animate-pulse"></div>
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  asChild
                  size="lg"
                  className={`bg-gradient-to-r ${module.gradient} hover:shadow-2xl transform hover:scale-105 transition-all duration-300 text-lg px-8 py-4 group`}
                >
                  <Link href={module.href} className="flex items-center gap-3">
                    <Play className="h-6 w-6 group-hover:animate-bounce" />
                    Aloita oppiminen
                  </Link>
                </Button>
              </div>

              {/* Visual */}
              <div className={`relative ${index % 2 === 1 ? "md:col-start-1" : ""}`}>
                <div
                  className={`bg-gradient-to-br ${module.bgGradient} p-8 rounded-3xl shadow-2xl transform hover:scale-105 transition-all duration-500 animate-float`}
                  style={{ animationDelay: `${index * 500}ms` }}
                >
                  <div className="bg-white/80 backdrop-blur-sm p-6 rounded-2xl shadow-xl">
                    <div className={`bg-gradient-to-r ${module.gradient} p-6 rounded-xl mb-4 flex justify-center`}>
                      <module.icon className="h-16 w-16 text-white animate-bounce" />
                    </div>
                    <div className="text-center">
                      <h3 className="font-bold text-gray-800 mb-2">{module.title}</h3>
                      <div className="flex justify-center gap-2">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className="h-4 w-4 text-yellow-400 fill-current animate-pulse"
                            style={{ animationDelay: `${i * 100}ms` }}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Floating Elements */}
                <div className="absolute -top-4 -right-4 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full p-3 shadow-xl animate-bounce">
                  <Sparkles className="h-6 w-6 text-blue-900" />
                </div>
                <div className="absolute -bottom-4 -left-4 bg-gradient-to-r from-green-400 to-blue-400 rounded-full p-3 shadow-xl animate-pulse">
                  <Star className="h-6 w-6 text-white" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Progress Indicator */}
        <div className="mt-20 text-center">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-8 rounded-3xl shadow-2xl max-w-2xl mx-auto">
            <Trophy className="h-12 w-12 mx-auto mb-4 text-yellow-400 animate-bounce" />
            <h3 className="text-2xl font-bold mb-4">Aloita matkasi tänään!</h3>
            <p className="text-blue-100 mb-6">
              Suorita kaikki neljä moduulia ja hanki todistus suomen kielen perustaidoistasi.
            </p>
            <div className="flex justify-center gap-2">
              {[...Array(4)].map((_, i) => (
                <div
                  key={i}
                  className="w-4 h-4 bg-blue-300 rounded-full animate-pulse"
                  style={{ animationDelay: `${i * 200}ms` }}
                ></div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes fade-in-up {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-float {
          animation: float 4s ease-in-out infinite;
        }
        .animate-spin-slow {
          animation: spin-slow 8s linear infinite;
        }
        .animate-fade-in-up {
          animation: fade-in-up 0.8s ease-out forwards;
        }
      `}</style>
    </div>
  )
}
