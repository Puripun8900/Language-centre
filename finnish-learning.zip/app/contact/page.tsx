import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Mail, Phone, MapPin, Clock } from "lucide-react"

export default function Contact() {
  return (
    <div className="w-full">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-5xl font-bold mb-6 text-gray-800">Ota yhteyttä</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Onko sinulla kysymyksiä suomen oppimisesta? Tarvitsetko apua alustan kanssa? Olemme täällä tukemassa
              oppimismatkaasi!
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-16">
            {/* Contact Form */}
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-8 rounded-2xl shadow-lg">
              <h2 className="text-3xl font-bold mb-8 text-gray-800">Lähetä meille viesti</h2>
              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="firstName" className="block text-sm font-medium mb-2 text-gray-700">
                      Etunimi
                    </label>
                    <Input id="firstName" placeholder="Etunimesi" className="w-full h-12" />
                  </div>
                  <div>
                    <label htmlFor="lastName" className="block text-sm font-medium mb-2 text-gray-700">
                      Sukunimi
                    </label>
                    <Input id="lastName" placeholder="Sukunimesi" className="w-full h-12" />
                  </div>
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium mb-2 text-gray-700">
                    Sähköpostiosoite
                  </label>
                  <Input id="email" type="email" placeholder="sinun.sahkoposti@esimerkki.com" className="w-full h-12" />
                </div>

                <div>
                  <label htmlFor="subject" className="block text-sm font-medium mb-2 text-gray-700">
                    Aihe
                  </label>
                  <Input id="subject" placeholder="Mistä tämä koskee?" className="w-full h-12" />
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium mb-2 text-gray-700">
                    Viesti
                  </label>
                  <Textarea
                    id="message"
                    placeholder="Kerro meille, miten voimme auttaa sinua suomen oppimisessa..."
                    rows={6}
                    className="w-full"
                  />
                </div>

                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-4">
                  Lähetä viesti
                </Button>
              </form>
            </div>

            {/* Contact Information */}
            <div className="space-y-8">
              <div>
                <h2 className="text-3xl font-bold mb-8 text-gray-800">Ota yhteyttä</h2>
                <p className="text-lg text-gray-600 mb-8">
                  Olemme sitoutuneet auttamaan kansainvälisiä opiskelijoita menestymään suomen oppimisessa. Ota meihin
                  yhteyttä millä tahansa seuraavista kanavista.
                </p>
              </div>

              <div className="space-y-6">
                <div className="flex items-start gap-4 p-6 bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow">
                  <div className="bg-blue-100 p-3 rounded-full">
                    <Mail className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-gray-800 mb-1">Sähköposti</h3>
                    <p className="text-gray-600">tuki@suomenoppiminen.com</p>
                    <p className="text-sm text-gray-500 mt-1">Vastaamme yleensä 24 tunnin sisällä</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-6 bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow">
                  <div className="bg-green-100 p-3 rounded-full">
                    <Phone className="h-6 w-6 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-gray-800 mb-1">Puhelin</h3>
                    <p className="text-gray-600">+358 123 456 789</p>
                    <p className="text-sm text-gray-500 mt-1">Maanantai - Perjantai, 9:00 - 17:00 (EET)</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-6 bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow">
                  <div className="bg-purple-100 p-3 rounded-full">
                    <MapPin className="h-6 w-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-gray-800 mb-1">Osoite</h3>
                    <p className="text-gray-600">
                      Suomen kielen oppimiskeskus
                      <br />
                      Mannerheimintie 123
                      <br />
                      00100 Helsinki, Suomi
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-6 bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow">
                  <div className="bg-orange-100 p-3 rounded-full">
                    <Clock className="h-6 w-6 text-orange-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-gray-800 mb-1">Aukioloajat</h3>
                    <div className="text-gray-600 space-y-1">
                      <p>Maanantai - Perjantai: 9:00 - 17:00</p>
                      <p>Lauantai: 10:00 - 14:00</p>
                      <p>Sunnuntai: Suljettu</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* FAQ Section */}
              <div className="bg-gray-50 p-6 rounded-xl">
                <h3 className="text-xl font-bold text-gray-800 mb-4">Usein kysytyt kysymykset</h3>
                <div className="space-y-3 text-sm">
                  <div>
                    <p className="font-medium text-gray-700">Kuinka kauan kaikkien moduulien suorittaminen kestää?</p>
                    <p className="text-gray-600">Useimmat opiskelijat suorittavat kaikki 4 moduulia 2-3 tunnissa.</p>
                  </div>
                  <div>
                    <p className="font-medium text-gray-700">Onko alustan käyttö ilmaista?</p>
                    <p className="text-gray-600">Kyllä, kaikki oppimismoduulit ovat täysin ilmaisia opiskelijoille.</p>
                  </div>
                  <div>
                    <p className="font-medium text-gray-700">Tarvitsenko kuulokkeet?</p>
                    <p className="text-gray-600">Kuulokkeet ovat suositeltavia parhaan äänikokemuksen saamiseksi.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
