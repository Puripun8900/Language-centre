"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { ThumbsUp } from "lucide-react"

export default function Feedback() {
  const [rating, setRating] = useState<string>("")
  const [suggestions, setSuggestions] = useState<string>("")
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
    // Here you would typically send the feedback to your backend
  }

  if (submitted) {
    return (
      <div className="w-full min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="max-w-md mx-auto text-center p-8">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <ThumbsUp className="h-8 w-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Kiitos palautteestasi!</h2>
            <p className="text-gray-600 mb-6">
              Arvostamme aikaasi ja mielipiteitäsi. Palautteesi auttaa meitä parantamaan oppimiskokemusta.
            </p>
            <Button asChild className="bg-blue-600 hover:bg-blue-700">
              <a href="/">Takaisin etusivulle</a>
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Blue feedback header */}
          <div className="bg-blue-600 text-white p-8 rounded-t-2xl">
            <div className="flex items-center gap-4">
              <ThumbsUp className="h-8 w-8" />
              <h1 className="text-4xl font-bold">Anna palautetta</h1>
            </div>
          </div>

          {/* White form area */}
          <div className="bg-white p-12 rounded-b-2xl shadow-lg">
            <p className="text-gray-700 mb-12 text-xl leading-relaxed">
              Arvostamme palautettasi oppimateriaaleistamme. Kerro meille kokemuksistasi ja mahdollisista
              parannusehdotuksista.
            </p>

            <form onSubmit={handleSubmit} className="space-y-10">
              <div>
                <label className="block text-lg font-medium text-gray-700 mb-6">
                  Miten arvioisit kokemuksesi oppimateriaaleistamme? *
                </label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  {[
                    { value: "erinomainen", label: "Erinomainen" },
                    { value: "hyva", label: "Hyvä" },
                    { value: "keskinkertainen", label: "Keskinkertainen" },
                    { value: "huono", label: "Huono" },
                  ].map((option) => (
                    <label key={option.value} className="flex items-center space-x-3 cursor-pointer">
                      <input
                        type="radio"
                        name="rating"
                        value={option.value}
                        checked={rating === option.value}
                        onChange={(e) => setRating(e.target.value)}
                        className="w-5 h-5 text-blue-600 border-gray-300 focus:ring-blue-500"
                        required
                      />
                      <span className="text-lg text-gray-700">{option.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label htmlFor="suggestions" className="block text-lg font-medium text-gray-700 mb-4">
                  Mitä voisimme parantaa?
                </label>
                <Textarea
                  id="suggestions"
                  placeholder="Your suggestions..."
                  value={suggestions}
                  onChange={(e) => setSuggestions(e.target.value)}
                  rows={8}
                  className="w-full border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-lg p-4"
                />
              </div>

              <Button
                type="submit"
                className="bg-blue-600 hover:bg-blue-700 text-white px-12 py-4 rounded-lg font-medium text-xl"
                disabled={!rating}
              >
                Lähetä palaute
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
