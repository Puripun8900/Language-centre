import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { BookOpen, Play, Award, Star, Trophy } from "lucide-react"

export default function Home() {
  return (
    <div className="w-full">
      {/* Hero Section - Reduced animations */}
      <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-purple-800 text-white relative overflow-hidden min-h-screen flex items-center">
        {/* Subtle background elements */}
        <div className="absolute inset-0">
          <div className="absolute top-20 left-20 w-32 h-32 bg-yellow-400/10 rounded-full"></div>
          <div className="absolute bottom-32 right-32 w-24 h-24 bg-blue-300/15 rounded-full"></div>
        </div>

        <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full flex items-center justify-center">
                    <Star className="h-6 w-6 text-blue-900" />
                  </div>
                  <span className="text-yellow-300 font-semibold text-lg">Tervetuloa!</span>
                </div>

                <h1 className="text-5xl md:text-7xl font-bold leading-tight">
                  <span className="bg-gradient-to-r from-white to-blue-100 bg-clip-text text-transparent">
                    Suomen kielen oppiminen
                  </span>
                  <span className="text-yellow-400">.</span>
                </h1>
                <h2 className="text-2xl md:text-3xl text-blue-100 font-light">Kansainvälisille opiskelijoille</h2>
              </div>

              <p className="text-xl text-blue-100 leading-relaxed max-w-lg">
                Tervetuloa suomen kielen oppimisalustalle! Tämä alusta on suunniteltu auttamaan kansainvälisiä
                opiskelijoita oppimaan suomen kielen sanastoa ja ilmaisuja, joita käytetään yleisesti työpaikoilla.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  asChild
                  size="lg"
                  className="bg-gradient-to-r from-yellow-400 to-orange-400 hover:from-yellow-500 hover:to-orange-500 text-blue-900 font-semibold text-lg px-8 py-4 shadow-xl hover:shadow-2xl transition-all duration-300"
                >
                  <Link href="/learn-finnish" className="flex items-center gap-3">
                    <Play className="h-6 w-6" />
                    Aloita oppiminen
                  </Link>
                </Button>
                <Button
                  asChild
                  variant="outline"
                  size="lg"
                  className="border-2 border-blue-300 text-white bg-white/10 backdrop-blur-sm hover:bg-white/20 hover:text-white text-lg px-8 py-4 font-semibold shadow-xl transition-all duration-300"
                >
                  <Link href="/feedback">Palautetta</Link>
                </Button>
              </div>
            </div>

            <div className="relative">
              <div className="bg-gradient-to-br from-white/20 to-white/10 backdrop-blur-sm p-6 rounded-3xl shadow-2xl border border-white/20">
                <Image
                  src="/images/lappeenranta.jpg"
                  alt="Suomalainen maisema - Lappeenranta"
                  width={600}
                  height={400}
                  className="rounded-2xl object-cover w-full shadow-2xl"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full p-6 shadow-2xl">
                <BookOpen className="h-10 w-10 text-blue-900" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section - Simplified */}
      <div className="bg-gradient-to-br from-gray-50 to-blue-50 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-800 to-purple-800 bg-clip-text text-transparent mb-4">
              Miten se toimii
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Kattava oppimisjärjestelmämme vie sinut neljän olennaisen moduulin läpi suomen kielen työpaikkasanaston
              hallitsemiseksi.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                number: "1",
                title: "Opi sanastoa",
                description:
                  "Aloita perussuomen sanastolla, joka liittyy työpaikan taukotiloihin ja kahviloihin ääntämisoppaiden kanssa.",
                gradient: "from-blue-500 to-blue-600",
                bgGradient: "from-blue-50 to-blue-100",
              },
              {
                number: "2",
                title: "Harjoittele kuuntelua",
                description: "Paranna kuuntelutaitojasi tunnistamalla esineitä ja seuraamalla ohjeita suomeksi.",
                gradient: "from-green-500 to-green-600",
                bgGradient: "from-green-50 to-green-100",
              },
              {
                number: "3",
                title: "Rakenna lauseita",
                description: "Opi muodostamaan lauseita ja käyttämään suomen verbejä oikein työpaikkayhteyksissä.",
                gradient: "from-purple-500 to-purple-600",
                bgGradient: "from-purple-50 to-purple-100",
              },
            ].map((feature, index) => (
              <div
                key={index}
                className={`bg-gradient-to-br ${feature.bgGradient} p-8 rounded-2xl text-center hover:shadow-xl transition-all duration-300 hover:-translate-y-2`}
              >
                <div
                  className={`bg-gradient-to-r ${feature.gradient} w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg`}
                >
                  <span className="text-white text-3xl font-bold">{feature.number}</span>
                </div>
                <h3 className="text-2xl font-bold mb-4 text-gray-800">{feature.title}</h3>
                <p className="text-gray-600 text-lg leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Stats Section - Simplified */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            {[
              { icon: BookOpen, number: "4", text: "Oppimismoduulia", color: "text-green-400" },
              { icon: Play, number: "50+", text: "Ääniharjoitusta", color: "text-purple-400" },
              { icon: Award, number: "95%", text: "Onnistumisprosentti", color: "text-yellow-400" },
            ].map((stat, index) => (
              <div key={index} className="space-y-4">
                <div className="flex justify-center">
                  <div className="bg-white/20 backdrop-blur-sm p-4 rounded-full">
                    <stat.icon className={`h-12 w-12 ${stat.color}`} />
                  </div>
                </div>
                <div className="text-4xl font-bold text-white">{stat.number}</div>
                <div className="text-blue-100 text-lg">{stat.text}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section - Simplified */}
      <div className="bg-gradient-to-br from-blue-800 via-blue-900 to-purple-900 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <div className="flex justify-center mb-6">
            <div className="bg-gradient-to-r from-yellow-400 to-orange-400 p-4 rounded-full">
              <Trophy className="h-12 w-12 text-blue-900" />
            </div>
          </div>
          <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-white to-blue-100 bg-clip-text text-transparent">
            Valmis aloittamaan suomen oppimisen?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Liity tuhansien kansainvälisten opiskelijoiden joukkoon, jotka oppivat jo suomea interaktiivisen alustamme
            avulla.
          </p>
          <Button
            asChild
            size="lg"
            className="bg-gradient-to-r from-yellow-400 to-orange-400 hover:from-yellow-500 hover:to-orange-500 text-blue-900 font-semibold text-xl px-12 py-6 shadow-2xl transition-all duration-300"
          >
            <Link href="/learn-finnish" className="flex items-center gap-3">
              <Play className="h-8 w-8" />
              Aloita matkasi
            </Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
