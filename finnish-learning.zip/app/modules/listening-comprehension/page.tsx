"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { Play, ArrowLeft, ArrowRight, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

// Define the questions and answers with updated coordinates
const questions = [
  {
    id: 1,
    question: "Ensin helppo sana. Missä on kahviautomaatti?",
    correctArea: { x1: 0.05, y1: 0.45, x2: 0.25, y2: 0.85 },
    correctFeedbackText:
      "Joo, se on kahviautomaatti. Sinä voit valita, millaista kahvia haluat. Otatko maitokahvia, espressoa vai jotain muuta? Minä tykkään tavallisesta mustasta kahvista.",
    incorrectFeedbackText: "Se ei ole kahviautomaatti. Kahviautomaatti on iso ja musta kone.",
  },
  {
    id: 2,
    question: "Tiedätkö, missä on vedenkeitin?",
    correctArea: { x1: 0.3, y1: 0.45, x2: 0.5, y2: 0.75 },
    correctFeedbackText:
      "Kyllä, se on valkoinen vedenkeitin. Tämän vedenkeittimen merkki on Smeg. Vedenkeitin on tosi hyödyllinen, koska voit keittää sillä kuumaa vettä nopeasti.",
    incorrectFeedbackText: "Se ei ole vedenkeitin. Vedenkeitin on valkoinen ja se on kahviautomaatin vieressä.",
  },
  {
    id: 3,
    question: "Missä on kahvitermos?",
    correctArea: { x1: 0.45, y1: 0.35, x2: 0.65, y2: 0.75 },
    correctFeedbackText:
      "Juu, se on kahvitermos. Tässä kahvilassa onkin kaksi kahvitermosta. Termoksessa on kuumaa kahvia.",
    incorrectFeedbackText: "Ei, se ei ole kahvitermos. Kuvassa on kaksi samanlaista kahvitermosta. Löydätkö ne?",
  },
  {
    id: 4,
    question: "Missä ovat teepussit? Löydätkö ne?",
    correctArea: { x1: 0.35, y1: 0.75, x2: 0.5, y2: 0.85 }, // Smaller square, focused on tea only
    correctFeedbackText: "Kyllä, siinä ovat teepussit. Minä juon yleensä mustaherukkateetä. Mistä teestä sinä tykkäät?",
    incorrectFeedbackText: "Nyt meni väärin. Teepussit ovat vedenkeittimen alapuolella.",
  },
  {
    id: 5,
    question: "Missä on hunajaa?",
    correctArea: { x1: 0.25, y1: 0.75, x2: 0.35, y2: 0.85 }, // Moved to left of tea
    correctFeedbackText: "Hyvä, löysit hunajan! Tässä on kaksi pulloa hunajaa. Minä käytän hunajaa, kun juon teetä.",
    incorrectFeedbackText: "Se ei ole hunajaa. Kokeile uudelleen!",
  },
  {
    id: 6,
    question: "Ja vielä lopuksi. Kuvassa on viisi purkkia makeutusainetta. Missä ne ovat?",
    correctArea: { x1: 0.5, y1: 0.75, x2: 0.65, y2: 0.85 }, // Moved to right of tea
    correctFeedbackText:
      "Hienoa, ne ovat makeutusainetta. Käytän makeutusainetta joskus kahvissa. Yleensä juon kahvia ilman makeutusainetta tai sokeria.",
    incorrectFeedbackText: "Se ei ole makeutusainetta. Makeutusaineet ovat teen oikealla puolella.",
  },
]

export default function ListeningComprehension() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedArea, setSelectedArea] = useState<{ x1: number; y1: number; x2: number; y2: number } | null>(null)
  const [feedback, setFeedback] = useState<{ text: string; isCorrect: boolean } | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)

  const question = questions[currentQuestion]

  // AI Voice synthesis function
  const speakFinnish = (text: string) => {
    setIsPlaying(true)

    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = "fi-FI"
      utterance.rate = 0.8
      utterance.pitch = 1

      utterance.onend = () => {
        setIsPlaying(false)
      }

      speechSynthesis.speak(utterance)
    }
  }

  const handleImageClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (feedback) return

    const rect = e.currentTarget.getBoundingClientRect()
    const x = (e.clientX - rect.left) / rect.width
    const y = (e.clientY - rect.top) / rect.height

    const isCorrect =
      x >= question.correctArea.x1 &&
      x <= question.correctArea.x2 &&
      y >= question.correctArea.y1 &&
      y <= question.correctArea.y2

    if (isCorrect) {
      setSelectedArea({
        x1: question.correctArea.x1 * 100,
        y1: question.correctArea.y1 * 100,
        x2: question.correctArea.x2 * 100,
        y2: question.correctArea.y2 * 100,
      })
      setFeedback({ text: question.correctFeedbackText, isCorrect: true })
      speakFinnish(question.correctFeedbackText)
    } else {
      setFeedback({ text: question.incorrectFeedbackText, isCorrect: false })
      speakFinnish(question.incorrectFeedbackText)
    }
  }

  const playQuestionAudio = () => {
    speakFinnish(question.question)
  }

  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setSelectedArea(null)
      setFeedback(null)
    } else {
      // Navigate to next module
      window.location.href = "/modules/word-practice"
    }
  }

  const handleTryAgain = () => {
    setSelectedArea(null)
    setFeedback(null)
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-80 bg-blue-900 text-white p-8 flex flex-col">
        <h2 className="text-2xl font-bold mb-8">Oppimispolku</h2>
        <ul className="space-y-6 flex-1">
          <li>
            <Link
              href="/modules/basic-vocabulary/intro"
              className="text-gray-300 text-lg block hover:text-white transition-colors"
            >
              • Perussanasto
            </Link>
            <div className="ml-6 mt-2 space-y-2">
              <Link
                href="/modules/basic-vocabulary/intro"
                className="text-gray-400 block hover:text-gray-200 transition-colors"
              >
                - Johdanto
              </Link>
              <Link
                href="/modules/basic-vocabulary"
                className="text-gray-400 block hover:text-gray-200 transition-colors"
              >
                - Harjoitus
              </Link>
            </div>
          </li>
          <li>
            <Link
              href="/modules/listening-comprehension/intro"
              className="text-yellow-300 font-semibold text-lg block hover:text-yellow-200 transition-colors"
            >
              • Kuullun ymmärtäminen
            </Link>
            <div className="ml-6 mt-2 space-y-2">
              <Link
                href="/modules/listening-comprehension/intro"
                className="text-gray-400 block hover:text-gray-200 transition-colors"
              >
                - Johdanto
              </Link>
              <Link
                href="/modules/listening-comprehension"
                className="text-yellow-200 block hover:text-yellow-100 transition-colors"
              >
                - Harjoitus
              </Link>
            </div>
          </li>
          <li>
            <Link
              href="/modules/word-practice"
              className="text-gray-300 text-lg block hover:text-white transition-colors"
            >
              • Sana- ja lauseharjoitukset
            </Link>
            <div className="ml-6 mt-2 space-y-2">
              <Link href="/modules/word-practice" className="text-gray-400 block hover:text-gray-200 transition-colors">
                - Harjoitus A
              </Link>
              <Link href="/modules/word-practice" className="text-gray-400 block hover:text-gray-200 transition-colors">
                - Harjoitus B
              </Link>
              <Link href="/modules/word-practice" className="text-gray-400 block hover:text-gray-200 transition-colors">
                - Harjoitus C
              </Link>
            </div>
          </li>
          <li>
            <Link
              href="/modules/listening-quiz"
              className="text-gray-300 text-lg block hover:text-white transition-colors"
            >
              • Kuullun ymmärtämisen testi
            </Link>
          </li>
        </ul>

        <div className="flex gap-4 mt-8">
          <Button
            variant="outline"
            size="md"
            asChild
            className="text-black bg-white border-white hover:bg-gray-100 hover:text-black flex-1 font-semibold"
          >
            <Link href="/modules/listening-comprehension/intro">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Takaisin
            </Link>
          </Button>
          <Button
            variant="outline"
            size="md"
            asChild
            className="text-black bg-white border-white hover:bg-gray-100 hover:text-black flex-1 font-semibold"
          >
            <Link href="/modules/word-practice">
              <ArrowRight className="h-4 w-4 mr-2" />
              Seuraava
            </Link>
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        <div className="bg-blue-900 text-white p-8">
          <h1 className="text-4xl font-bold mb-4">Moduuli 2</h1>
          <div className="bg-blue-800 p-6 rounded-lg">
            <h2 className="text-3xl font-bold mb-3">Kuullun ymmärtäminen</h2>
            <p className="text-blue-100 text-xl">
              Tässä on kuva kahvilasta. Kuuntele mitä työtoverisi sanoo ja löydä esineet kuvasta. Klikkaa tai napauta
              esinettä.
            </p>
          </div>
        </div>

        <div className="flex-1 p-8 overflow-auto">
          <div className="relative">
            <div
              className="relative cursor-pointer group"
              onClick={handleImageClick}
              style={{ pointerEvents: feedback ? "none" : "auto" }}
            >
              <Image
                src="/images/modula2.jpg"
                alt="Kahvilakuva"
                width={1200}
                height={675}
                className="w-full rounded-xl shadow-2xl transition-transform group-hover:scale-[1.02]"
              />

              {/* Highlight selected area if correct */}
              {selectedArea && (
                <div
                  className="absolute border-4 border-red-500 bg-red-500 bg-opacity-20 rounded-lg animate-pulse"
                  style={{
                    left: `${selectedArea.x1}%`,
                    top: `${selectedArea.y1}%`,
                    width: `${selectedArea.x2 - selectedArea.x1}%`,
                    height: `${selectedArea.y2 - selectedArea.y1}%`,
                  }}
                />
              )}
            </div>

            {/* Question and audio player */}
            <div className="bg-gradient-to-r from-blue-100 to-blue-200 p-8 mt-8 rounded-xl shadow-lg flex items-center gap-6">
              <button
                onClick={playQuestionAudio}
                className="bg-blue-600 text-white p-6 rounded-full hover:bg-blue-700 transition-all duration-300 hover:scale-110 shadow-lg"
                disabled={isPlaying}
              >
                <Play className="h-8 w-8" />
              </button>
              <p className="text-2xl font-medium text-gray-800">{question.question}</p>
            </div>

            {/* Feedback message */}
            {feedback && (
              <div
                className={`p-8 mt-8 rounded-xl shadow-lg border-l-4 ${
                  feedback.isCorrect
                    ? "bg-green-50 text-green-800 border-green-500"
                    : "bg-red-50 text-red-800 border-red-500"
                }`}
              >
                <div className="flex items-start gap-4">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xl ${
                      feedback.isCorrect ? "bg-green-500" : "bg-red-500"
                    }`}
                  >
                    {feedback.isCorrect ? "✓" : "✗"}
                  </div>
                  <p className="text-2xl leading-relaxed">{feedback.text}</p>
                </div>
              </div>
            )}

            {/* Navigation buttons */}
            <div className="flex justify-end mt-12">
              <div className="flex gap-4">
                {feedback && !feedback.isCorrect && (
                  <Button
                    onClick={handleTryAgain}
                    className="bg-blue-600 hover:bg-blue-700 text-xl px-8 py-4 flex items-center gap-3"
                  >
                    <RotateCcw className="h-6 w-6" />
                    Yritä uudelleen
                  </Button>
                )}
                {feedback && feedback.isCorrect && (
                  <Button onClick={handleNextQuestion} className="bg-green-600 hover:bg-green-700 text-xl px-8 py-4">
                    {currentQuestion < questions.length - 1 ? "Seuraava kysymys" : "Seuraava moduuli"}
                  </Button>
                )}
              </div>
            </div>

            {/* Progress indicator */}
            <div className="mt-8 bg-white p-6 rounded-lg shadow-md">
              <div className="flex justify-between items-center mb-3">
                <span className="text-lg font-medium text-gray-600">Edistyminen</span>
                <span className="text-lg font-medium text-gray-600">
                  {currentQuestion + 1} / {questions.length}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-blue-600 h-3 rounded-full transition-all duration-300"
                  style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
