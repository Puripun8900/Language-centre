"use client"

import Image from "next/image"
import { ArrowLeft, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function ListeningComprehensionIntro() {
  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-80 bg-blue-900 text-white p-8 flex flex-col">
        <h2 className="text-2xl font-bold mb-8">Oppimispolku</h2>
        <ul className="space-y-6 flex-1">
          <li>
            <Link
              href="/modules/basic-vocabulary/intro"
              className="text-gray-300 text-lg block hover:text-white transition-colors"
            >
              • Perussanasto
            </Link>
            <div className="ml-6 mt-2 space-y-2">
              <Link
                href="/modules/basic-vocabulary/intro"
                className="text-gray-400 block hover:text-gray-200 transition-colors"
              >
                - Johdanto
              </Link>
              <Link
                href="/modules/basic-vocabulary"
                className="text-gray-400 block hover:text-gray-200 transition-colors"
              >
                - Harjoitus
              </Link>
            </div>
          </li>
          <li>
            <Link
              href="/modules/listening-comprehension/intro"
              className="text-yellow-300 font-semibold text-lg block hover:text-yellow-200 transition-colors"
            >
              • Kuullun ymmärtäminen
            </Link>
            <div className="ml-6 mt-2 space-y-2">
              <Link
                href="/modules/listening-comprehension/intro"
                className="text-yellow-200 block hover:text-yellow-100 transition-colors"
              >
                - Johdanto
              </Link>
              <Link
                href="/modules/listening-comprehension"
                className="text-gray-400 block hover:text-gray-200 transition-colors"
              >
                - Harjoitus
              </Link>
            </div>
          </li>
          <li>
            <Link
              href="/modules/word-practice"
              className="text-gray-300 text-lg block hover:text-white transition-colors"
            >
              • Sana- ja lauseharjoitukset
            </Link>
            <div className="ml-6 mt-2 space-y-2">
              <Link href="/modules/word-practice" className="text-gray-400 block hover:text-gray-200 transition-colors">
                - Harjoitus A
              </Link>
              <Link href="/modules/word-practice" className="text-gray-400 block hover:text-gray-200 transition-colors">
                - Harjoitus B
              </Link>
              <Link href="/modules/word-practice" className="text-gray-400 block hover:text-gray-200 transition-colors">
                - Harjoitus C
              </Link>
            </div>
          </li>
          <li>
            <Link
              href="/modules/listening-quiz"
              className="text-gray-300 text-lg block hover:text-white transition-colors"
            >
              • Kuullun ymmärtämisen testi
            </Link>
          </li>
        </ul>

        <div className="flex gap-4 mt-8">
          <Button
            variant="outline"
            size="md"
            asChild
            className="text-black bg-white border-white hover:bg-gray-100 hover:text-black flex-1 font-semibold"
          >
            <Link href="/modules/basic-vocabulary">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Takaisin
            </Link>
          </Button>
          <Button
            variant="outline"
            size="md"
            asChild
            className="text-black bg-white border-white hover:bg-gray-100 hover:text-black flex-1 font-semibold"
          >
            <Link href="/modules/listening-comprehension">
              <ArrowRight className="h-4 w-4 mr-2" />
              Seuraava
            </Link>
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 relative">
        {/* Background Image */}
        <div className="absolute inset-0">
          <Image src="/images/modula2.jpg" alt="Kahvilakuva" fill className="object-cover" />
          <div className="absolute inset-0 bg-black/50"></div>
        </div>

        {/* Content Overlay */}
        <div className="relative z-10 flex items-center justify-center h-full p-12">
          <div className="max-w-5xl w-full">
            {/* Speech Bubble - Removed "Moduuli 2" */}
            <div className="bg-blue-600 text-white p-16 rounded-3xl shadow-2xl relative">
              <div className="absolute bottom-0 left-20 w-0 h-0 border-l-[40px] border-l-transparent border-r-[40px] border-r-transparent border-t-[40px] border-t-blue-600 transform translate-y-full"></div>

              <p className="text-3xl leading-relaxed mb-12">
                Tässä on kuva kahvilasta. Kuuntele, mitä sinun työtoverisi sanoo, ja etsi kuvatut tavarat. Klikkaa tai
                napauta tavaraa.
              </p>

              <div className="flex justify-center">
                <Button
                  asChild
                  size="lg"
                  className="bg-yellow-400 hover:bg-yellow-500 text-blue-900 px-16 py-4 rounded-xl font-bold text-2xl"
                >
                  <Link href="/modules/listening-comprehension">Aloita</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
