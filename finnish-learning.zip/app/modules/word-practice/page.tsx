"use client"

import { useState } from "react"
import { ArrowLeft, ArrowRight, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

// Define the exercises
const exerciseA = {
  title: "A. Harjoittele lisää sanoja. Yhdistä lauseet oikein.",
  leftItems: [
    { id: 1, text: "Haluaisitko" },
    { id: 2, text: "Laitatko kahviin" },
    { id: 3, text: "Käytätkö teessä" },
    { id: 4, text: "Otatko jotain" },
    { id: 5, text: "Keitätkö vettä" },
    { id: 6, text: "Onko kahvitermoksessa" },
  ],
  rightItems: [
    { id: 1, text: "makeutusainetta?" },
    { id: 2, text: "ottaa kahvia vai teetä?" },
    { id: 3, text: "hunajaa?" },
    { id: 4, text: "kahviautomaatista?" },
    { id: 5, text: "vedenkeitinmellä?" },
    { id: 6, text: "vielä kahvia?" },
  ],
  correctMatches: { 1: 2, 2: 3, 3: 1, 4: 4, 5: 6, 6: 5 },
}

const exerciseB = {
  title: "B. Harjoittele lisää sanoja. Yhdistä lauseet oikein.",
  leftItems: [
    { id: 1, text: "Kahvitermos" },
    { id: 2, text: "Vedenkeitin ei" },
    { id: 3, text: "Kahviautomaatti" },
    { id: 4, text: "Teepussit ovat" },
    { id: 5, text: "Juomalasit" },
    { id: 6, text: "Kakkupalat" },
  ],
  rightItems: [
    { id: 1, text: "on rikki." },
    { id: 2, text: "ovat hyllyllä." },
    { id: 3, text: "on tyhjä." },
    { id: 4, text: "maistuvat herkulliselta." },
    { id: 5, text: "toimi." },
    { id: 6, text: "laatikossa." },
  ],
  correctMatches: { 1: 3, 2: 5, 3: 1, 4: 6, 5: 2, 6: 4 },
}

const exerciseC = {
  title: "C. Selvitä mitä seuraavat verbit tarkoittavat:",
  verbs: ["ottaa", "laittaa", "sekoittaa", "käyttää", "kaataa", "keittää"],
  sentences: [
    { id: 1, text: "sinä kahvia vai teetä?", correctVerb: "Otatko" },
    { id: 2, text: "vähän teevettä vedenkeitinmellä?", correctVerb: "Keitätkö" },
    { id: 3, text: "sinä kahvissa makeutusainetta?", correctVerb: "Käytätkö" },
    { id: 4, text: "testaset astiat tuolle pöydälle?", correctVerb: "Laitatko" },
    { id: 5, text: "minulle vähän lisää kahvia tähän kuppiin?", correctVerb: "Kaadatko" },
    { id: 6, text: "sinä teehen hunajaa?", correctVerb: "Sekoitatko" },
  ],
}

export default function WordPractice() {
  const [currentSection, setCurrentSection] = useState<"A" | "B" | "C">("A")
  const [matchesA, setMatchesA] = useState<{ [key: number]: number }>({})
  const [matchesB, setMatchesB] = useState<{ [key: number]: number }>({})
  const [verbAnswers, setVerbAnswers] = useState<{ [key: number]: string }>({})
  const [showResults, setShowResults] = useState(false)
  const [selectedLeft, setSelectedLeft] = useState<number | null>(null)
  const [allCorrect, setAllCorrect] = useState(false)

  // AI Voice synthesis function
  const speakText = (text: string, lang = "fi-FI") => {
    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = lang
      utterance.rate = 0.7
      utterance.pitch = 1
      speechSynthesis.speak(utterance)
    }
  }

  const handleLeftClick = (id: number) => {
    if (showResults) return
    setSelectedLeft(id)
    // Speak the Finnish text
    const exercise = currentSection === "A" ? exerciseA : exerciseB
    const item = exercise.leftItems.find((item) => item.id === id)
    if (item) {
      speakText(item.text, "fi-FI")
    }
  }

  const handleRightClick = (id: number) => {
    if (showResults || selectedLeft === null) return

    if (currentSection === "A") {
      // Clear any existing match for this left item
      const newMatches = { ...matchesA }
      // Remove any existing match for the selected left item
      delete newMatches[selectedLeft]
      // Add new match
      newMatches[selectedLeft] = id
      setMatchesA(newMatches)
    } else if (currentSection === "B") {
      const newMatches = { ...matchesB }
      delete newMatches[selectedLeft]
      newMatches[selectedLeft] = id
      setMatchesB(newMatches)
    }

    setSelectedLeft(null)

    // Speak the Finnish text
    const exercise = currentSection === "A" ? exerciseA : exerciseB
    const item = exercise.rightItems.find((item) => item.id === id)
    if (item) {
      speakText(item.text, "fi-FI")
    }
  }

  const handleVerbInput = (sentenceId: number, value: string) => {
    if (showResults) return
    setVerbAnswers((prev) => ({ ...prev, [sentenceId]: value }))
  }

  const checkAnswers = () => {
    setShowResults(true)
    setAllCorrect(false)

    if (currentSection === "A" || currentSection === "B") {
      const exercise = currentSection === "A" ? exerciseA : exerciseB
      const matches = currentSection === "A" ? matchesA : matchesB
      const correctCount = Object.entries(matches).filter(
        ([leftId, rightId]) => exercise.correctMatches[Number.parseInt(leftId)] === rightId,
      ).length
      const percentage = Math.round((correctCount / exercise.leftItems.length) * 100)

      if (correctCount === exercise.leftItems.length) {
        speakText("Erinomaista! Kaikki vastaukset ovat oikein!", "fi-FI")
        setAllCorrect(true)
      } else {
        speakText(`${percentage} prosenttia oikein`, "fi-FI")
      }
    } else {
      const correctCount = exerciseC.sentences.filter(
        (sentence) => verbAnswers[sentence.id]?.toLowerCase() === sentence.correctVerb.toLowerCase(),
      ).length
      const percentage = Math.round((correctCount / exerciseC.sentences.length) * 100)

      if (correctCount === exerciseC.sentences.length) {
        speakText("Täydellista! Kaikki verbit ovat oikein!", "fi-FI")
        setAllCorrect(true)
      } else {
        speakText(`${percentage} prosenttia oikein`, "fi-FI")
      }
    }
  }

  const resetExercise = () => {
    if (currentSection === "A") {
      setMatchesA({})
    } else if (currentSection === "B") {
      setMatchesB({})
    } else {
      setVerbAnswers({})
    }
    setShowResults(false)
    setSelectedLeft(null)
    setAllCorrect(false)
  }

  const getMatchColor = (leftId: number, rightId: number, exercise: typeof exerciseA) => {
    const matches = currentSection === "A" ? matchesA : matchesB
    const isMatched = matches[leftId] === rightId
    const isCorrect = exercise.correctMatches[leftId] === rightId

    if (!showResults || !isMatched) return ""
    return isCorrect ? "text-green-600 bg-green-50 border-green-300" : "text-red-600 bg-red-50 border-red-300"
  }

  const isRightItemUsed = (rightId: number) => {
    const matches = currentSection === "A" ? matchesA : matchesB
    return Object.values(matches).includes(rightId)
  }

  // Function to get complete sentence when both parts are matched
  const getCompleteSentence = (leftId: number, exercise: typeof exerciseA) => {
    const matches = currentSection === "A" ? matchesA : matchesB
    const rightId = matches[leftId]
    if (!rightId) return null

    const leftItem = exercise.leftItems.find((item) => item.id === leftId)
    const rightItem = exercise.rightItems.find((item) => item.id === rightId)

    if (leftItem && rightItem) {
      return `${leftItem.text} ${rightItem.text}`
    }
    return null
  }

  const renderExerciseAB = (exercise: typeof exerciseA) => {
    const matches = currentSection === "A" ? matchesA : matchesB

    return (
      <div className="space-y-12">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-blue-900 mb-6">{exercise.title}</h2>
          <p className="text-gray-600 text-2xl">Klikkaa suomalaista lausetta, sitten klikkaa sen jatkoa</p>
        </div>

        {/* Show completed sentences when matched - with better spacing */}
        {Object.keys(matches).length > 0 && (
          <div className="bg-blue-50 p-8 rounded-xl">
            <h3 className="text-2xl font-bold text-blue-900 mb-6">Yhdistetyt lauseet:</h3>
            <div className="space-y-6">
              {Object.keys(matches).map((leftId) => {
                const completeSentence = getCompleteSentence(Number.parseInt(leftId), exercise)
                const isCorrect = exercise.correctMatches[Number.parseInt(leftId)] === matches[Number.parseInt(leftId)]

                if (completeSentence) {
                  return (
                    <div
                      key={leftId}
                      className={`p-6 rounded-lg border-2 text-xl font-medium transition-all duration-300 ${
                        showResults
                          ? isCorrect
                            ? "bg-green-100 border-green-500 text-green-800"
                            : "bg-red-100 border-red-500 text-red-800"
                          : "bg-blue-100 border-blue-300 text-blue-800"
                      }`}
                      onClick={() => speakText(completeSentence, "fi-FI")}
                    >
                      <div className="flex items-center gap-4">
                        {showResults && (
                          <span className={`text-2xl ${isCorrect ? "text-green-600" : "text-red-600"}`}>
                            {isCorrect ? "✓" : "✗"}
                          </span>
                        )}
                        <span className="cursor-pointer hover:underline leading-relaxed">{completeSentence}</span>
                      </div>
                    </div>
                  )
                }
                return null
              })}
            </div>
          </div>
        )}

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left column - Finnish */}
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">Suomalaiset lauseet</h3>
            {exercise.leftItems.map((item) => (
              <div
                key={item.id}
                className={`p-6 rounded-xl cursor-pointer transition-all duration-300 border-2 text-xl ${
                  selectedLeft === item.id
                    ? "bg-blue-200 border-blue-500 shadow-lg transform scale-105"
                    : matches[item.id]
                      ? "bg-gray-200 border-gray-400"
                      : "bg-gray-100 hover:bg-gray-200 border-transparent hover:border-gray-300"
                } ${getMatchColor(item.id, matches[item.id], exercise)}`}
                onClick={() => handleLeftClick(item.id)}
              >
                <span className="font-bold text-blue-900">{item.id})</span> {item.text}
              </div>
            ))}
          </div>

          {/* Right column - Finnish */}
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">Lauseiden jatkot</h3>
            {exercise.rightItems.map((item) => (
              <div
                key={item.id}
                className={`p-6 rounded-xl cursor-pointer transition-all duration-300 border-2 text-xl ${
                  isRightItemUsed(item.id)
                    ? "bg-blue-100 border-blue-300 shadow-md"
                    : "bg-gray-100 hover:bg-gray-200 border-transparent hover:border-gray-300"
                } ${
                  Object.entries(matches).find(([_, rightId]) => rightId === item.id)
                    ? getMatchColor(
                        Number.parseInt(Object.entries(matches).find(([_, rightId]) => rightId === item.id)![0]),
                        item.id,
                        exercise,
                      )
                    : ""
                }`}
                onClick={() => handleRightClick(item.id)}
              >
                {item.text}
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  const renderExerciseC = () => (
    <div className="space-y-12">
      <div className="text-center">
        <h2 className="text-4xl font-bold text-blue-900 mb-6">{exerciseC.title}</h2>
        <p className="text-gray-600 text-2xl">Kirjoita oikea verbi jokaiseen lauseeseen</p>
      </div>

      {/* Available verbs */}
      <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-8 rounded-xl">
        <h3 className="text-2xl font-bold text-gray-800 mb-6">Käytettävissä olevat verbit:</h3>
        <div className="flex flex-wrap gap-4">
          {exerciseC.verbs.map((verb) => (
            <span
              key={verb}
              className="px-6 py-3 bg-white rounded-lg font-medium shadow-md hover:shadow-lg transition-shadow cursor-pointer text-xl"
              onClick={() => speakText(verb, "fi-FI")}
            >
              {verb}
            </span>
          ))}
        </div>
      </div>

      <div className="bg-white p-8 rounded-xl shadow-lg">
        <h3 className="text-2xl font-bold text-gray-800 mb-8">Täydennä lauseet:</h3>
        <div className="space-y-8">
          {exerciseC.sentences.map((sentence) => (
            <div key={sentence.id} className="flex items-center gap-6 p-6 bg-gray-50 rounded-lg">
              <span className="font-bold text-blue-900 min-w-[30px] text-xl">{sentence.id}.</span>
              <input
                type="text"
                value={verbAnswers[sentence.id] || ""}
                onChange={(e) => handleVerbInput(sentence.id, e.target.value)}
                placeholder="Kirjoita verbi tähän"
                className={`px-6 py-3 border-2 rounded-lg text-xl font-medium transition-colors min-w-[200px] ${
                  showResults
                    ? verbAnswers[sentence.id]?.toLowerCase() === sentence.correctVerb.toLowerCase()
                      ? "border-green-500 bg-green-50 text-green-800"
                      : "border-red-500 bg-red-50 text-red-800"
                    : "border-gray-300 hover:border-blue-400 focus:border-blue-500"
                }`}
                disabled={showResults}
              />
              <span className="text-xl flex-1">{sentence.text}</span>
              {showResults && (
                <span
                  className={`font-bold text-2xl ${
                    verbAnswers[sentence.id]?.toLowerCase() === sentence.correctVerb.toLowerCase()
                      ? "text-green-600"
                      : "text-red-600"
                  }`}
                >
                  {verbAnswers[sentence.id]?.toLowerCase() === sentence.correctVerb.toLowerCase() ? "✓" : "✗"}
                </span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-80 bg-blue-900 text-white p-8 flex flex-col">
        <h2 className="text-2xl font-bold mb-8">Oppimispolku</h2>
        <ul className="space-y-6 flex-1">
          <li>
            <Link
              href="/modules/basic-vocabulary/intro"
              className="text-gray-300 text-lg block hover:text-white transition-colors"
            >
              • Perussanasto
            </Link>
            <div className="ml-6 mt-2 space-y-2">
              <Link
                href="/modules/basic-vocabulary/intro"
                className="text-gray-400 block hover:text-gray-200 transition-colors"
              >
                - Johdanto
              </Link>
              <Link
                href="/modules/basic-vocabulary"
                className="text-gray-400 block hover:text-gray-200 transition-colors"
              >
                - Harjoitus
              </Link>
            </div>
          </li>
          <li>
            <Link
              href="/modules/listening-comprehension/intro"
              className="text-gray-300 text-lg block hover:text-white transition-colors"
            >
              • Kuullun ymmärtäminen
            </Link>
            <div className="ml-6 mt-2 space-y-2">
              <Link
                href="/modules/listening-comprehension/intro"
                className="text-gray-400 block hover:text-gray-200 transition-colors"
              >
                - Johdanto
              </Link>
              <Link
                href="/modules/listening-comprehension"
                className="text-gray-400 block hover:text-gray-200 transition-colors"
              >
                - Harjoitus
              </Link>
            </div>
          </li>
          <li>
            <Link
              href="/modules/word-practice"
              className="text-yellow-300 font-semibold text-lg block hover:text-yellow-200 transition-colors"
            >
              • Sana- ja lauseharjoitukset
            </Link>
            <div className="ml-6 mt-2 space-y-2">
              <button
                onClick={() => setCurrentSection("A")}
                className={`text-left block hover:text-yellow-100 transition-colors ${
                  currentSection === "A" ? "text-yellow-200" : "text-gray-400 hover:text-gray-200"
                }`}
              >
                - Harjoitus A
              </button>
              <button
                onClick={() => setCurrentSection("B")}
                className={`text-left block hover:text-yellow-100 transition-colors ${
                  currentSection === "B" ? "text-yellow-200" : "text-gray-400 hover:text-gray-200"
                }`}
              >
                - Harjoitus B
              </button>
              <button
                onClick={() => setCurrentSection("C")}
                className={`text-left block hover:text-yellow-100 transition-colors ${
                  currentSection === "C" ? "text-yellow-200" : "text-gray-400 hover:text-gray-200"
                }`}
              >
                - Harjoitus C
              </button>
            </div>
          </li>
          <li>
            <Link
              href="/modules/listening-quiz"
              className="text-gray-300 text-lg block hover:text-white transition-colors"
            >
              • Kuullun ymmärtämisen testi
            </Link>
          </li>
        </ul>

        <div className="flex gap-4 mt-8">
          <Button
            variant="outline"
            size="md"
            asChild
            className="text-black bg-white border-white hover:bg-gray-100 hover:text-black flex-1 font-semibold"
          >
            <Link href="/modules/listening-comprehension">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Takaisin
            </Link>
          </Button>
          <Button
            variant="outline"
            size="md"
            asChild
            className="text-black bg-white border-white hover:bg-gray-100 hover:text-black flex-1 font-semibold"
          >
            <Link href="/modules/listening-quiz">
              <ArrowRight className="h-4 w-4 mr-2" />
              Seuraava
            </Link>
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        <div className="bg-gradient-to-r from-blue-700 to-blue-900 text-white p-8">
          <h1 className="text-4xl font-bold mb-4"></h1>
          <h2 className="text-3xl font-bold">Sanojen ja lauseiden harjoittelu</h2>
        </div>

        <div className="flex-1 p-8 overflow-auto">
          {/* Section tabs - now functional */}
          <div className="flex gap-4 mb-12 justify-center">
            {(["A", "B", "C"] as const).map((section) => (
              <Button
                key={section}
                variant={currentSection === section ? "default" : "outline"}
                onClick={() => {
                  setCurrentSection(section)
                  setShowResults(false)
                  setSelectedLeft(null)
                  setAllCorrect(false)
                }}
                className={`text-2xl px-12 py-4 ${
                  currentSection === section ? "bg-blue-600 hover:bg-blue-700" : "hover:bg-blue-50"
                }`}
              >
                Harjoitus {section}
              </Button>
            ))}
          </div>

          {/* Exercise content */}
          <div className="max-w-7xl mx-auto">
            {currentSection === "A" && renderExerciseAB(exerciseA)}
            {currentSection === "B" && renderExerciseAB(exerciseB)}
            {currentSection === "C" && renderExerciseC()}
          </div>

          {/* Action buttons */}
          <div className="flex justify-center gap-6 mt-16">
            {!showResults ? (
              <Button
                onClick={checkAnswers}
                className="bg-blue-600 hover:bg-blue-700 text-2xl px-12 py-4"
                disabled={
                  (currentSection === "A" && Object.keys(matchesA).length === 0) ||
                  (currentSection === "B" && Object.keys(matchesB).length === 0) ||
                  (currentSection === "C" && Object.keys(verbAnswers).length === 0)
                }
              >
                Tarkista
              </Button>
            ) : (
              <Button
                onClick={resetExercise}
                className="bg-blue-600 hover:bg-blue-700 text-2xl px-12 py-4 flex items-center gap-3"
              >
                <RotateCcw className="h-6 w-6" />
                Yritä uudelleen
              </Button>
            )}
          </div>

          {/* Results Summary */}
          {showResults && !allCorrect && (
            <div className="max-w-3xl mx-auto mt-12 bg-white p-8 rounded-xl shadow-lg">
              <h3 className="text-3xl font-bold text-center mb-6">Tulokset</h3>
              <div className="text-center">
                {currentSection === "A" || currentSection === "B" ? (
                  <>
                    <div className="text-6xl font-bold text-blue-600 mb-4">
                      {Math.round(
                        (Object.entries(currentSection === "A" ? matchesA : matchesB).filter(
                          ([leftId, rightId]) =>
                            (currentSection === "A" ? exerciseA : exerciseB).correctMatches[Number.parseInt(leftId)] ===
                            rightId,
                        ).length /
                          (currentSection === "A" ? exerciseA : exerciseB).leftItems.length) *
                          100,
                      )}
                      %
                    </div>
                    <p className="text-gray-600 text-2xl">Oikeita yhdistämisiä</p>
                  </>
                ) : (
                  <>
                    <div className="text-6xl font-bold text-blue-600 mb-4">
                      {Math.round(
                        (exerciseC.sentences.filter(
                          (sentence) => verbAnswers[sentence.id]?.toLowerCase() === sentence.correctVerb.toLowerCase(),
                        ).length /
                          exerciseC.sentences.length) *
                          100,
                      )}
                      %
                    </div>
                    <p className="text-gray-600 text-2xl">Oikeita verbejä</p>
                  </>
                )}
              </div>
            </div>
          )}

          {/* Congratulations */}
          {showResults && allCorrect && (
            <div className="max-w-5xl mx-auto mt-12 bg-green-100 border-2 border-green-500 p-8 rounded-xl shadow-lg">
              <h3 className="text-4xl font-bold text-center text-green-800 mb-6">
                Onneksi olkoon! Kaikki vastaukset ovat oikein! 🎉
              </h3>
              <p className="text-gray-700 text-center text-2xl mb-8">
                Olet suorittanut tämän osion erinomaisesti. Jatka seuraavaan osioon vahvistaaksesi oppimistasi.
              </p>
              <div className="flex justify-center">
                <Button asChild className="bg-green-600 hover:bg-green-700 text-white text-2xl px-12 py-4">
                  <Link href="/modules/listening-quiz">
                    Seuraava Moduuli <ArrowRight className="h-6 w-6 ml-2" />
                  </Link>
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
