"use client"

import { useState } from "react"
import Image from "next/image"
import { Play, ArrowLeft, CheckCircle, Trophy, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

// Define the quiz questions
const questions = [
  {
    id: 1,
    statement: "Kahvilan seinä on vihreä.",
    correctAnswer: false,
    correctFeedback: "Kahvilan seinä ei ole vihreä, vaan keltainen.",
    incorrectFeedback: "Kahvilan seinä ei ole vihreä, vaan keltainen.",
  },
  {
    id: 2,
    statement: "Pöydällä on keltaista mehua.",
    correctAnswer: true,
    correctFeedback: "Pöydällä on keltaista mehua. Se on ehkä appelsiinimehua.",
    incorrectFeedback: "Pöydällä on keltaista mehua. Se on ehkä appelsiinimehua.",
  },
  {
    id: 3,
    statement: "Asiakas voi ottaa kahvia kahviautomaatista.",
    correctAnswer: false,
    correctFeedback: "Kahvi on pöydällä kahvitermoksessa, ei automaatissa.",
    incorrectFeedback: "Kahvi on pöydällä kahvitermoksessa, ei automaatissa.",
  },
  {
    id: 4,
    statement: "Asiakas voi saada kakkua ja keksejä.",
    correctAnswer: true,
    correctFeedback: "Pöydällä on vaaleita keksejä ja tummaa kakkua. Se on ehkä suklaakakkua.",
    incorrectFeedback: "Pöydällä on vaaleita keksejä ja tummaa kakkua. Se on ehkä suklaakakkua.",
  },
  {
    id: 5,
    statement: "Kaikki lasit ovat pöydällä.",
    correctAnswer: false,
    correctFeedback: "Lasit ovat hyllyllä, pöydän yläpuolella.",
    incorrectFeedback: "Lasit ovat hyllyllä, pöydän yläpuolella.",
  },
  {
    id: 6,
    statement: "Kahvitermoksen takana on koriste-esine.",
    correctAnswer: true,
    correctFeedback: "Kahvitermoksen takana on kaunis patsas.",
    incorrectFeedback: "Kahvitermoksen takana on kaunis patsas.",
  },
]

export default function ListeningQuiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<boolean | null>(null)
  const [showFeedback, setShowFeedback] = useState(false)
  const [isPlaying, setIsPlaying] = useState(false)
  const [score, setScore] = useState(0)
  const [quizCompleted, setQuizCompleted] = useState(false)
  const [showCongratulations, setShowCongratulations] = useState(false)

  const question = questions[currentQuestion]

  // AI Voice synthesis function
  const speakFinnish = (text: string) => {
    setIsPlaying(true)

    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = "fi-FI"
      utterance.rate = 0.8
      utterance.pitch = 1

      utterance.onend = () => {
        setIsPlaying(false)
      }

      speechSynthesis.speak(utterance)
    }
  }

  const handleAnswerSelect = (answer: boolean) => {
    setSelectedAnswer(answer)
    setShowFeedback(true)

    // Update score if correct
    if (answer === question.correctAnswer) {
      setScore((prev) => prev + 1)
    }

    // Speak feedback
    const feedbackText = answer === question.correctAnswer ? question.correctFeedback : question.incorrectFeedback
    speakFinnish(feedbackText)
  }

  const playAudio = () => {
    speakFinnish(question.statement)
  }

  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setSelectedAnswer(null)
      setShowFeedback(false)
    } else {
      // Quiz completed
      setQuizCompleted(true)
      const finalScore = score + (selectedAnswer === question.correctAnswer ? 1 : 0)

      // Check if perfect score
      if (finalScore === questions.length) {
        setShowCongratulations(true)
        speakFinnish("Onnittelut! Kaikki vastaukset ovat oikein!")
      } else {
        // Calculate overall score from all 4 modules
        const module1Score = 85
        const module2Score = 90
        const module3Score = 80
        const module4Score = Math.round((finalScore / questions.length) * 100)
        const overallScore = Math.round((module1Score + module2Score + module3Score + module4Score) / 4)
        speakFinnish(`Kaikki moduulit suoritettu! Kokonaispistemääräsi on ${overallScore} prosenttia.`)
      }
    }
  }

  const isCorrectAnswer = selectedAnswer === question.correctAnswer
  const feedbackText = isCorrectAnswer ? question.correctFeedback : question.incorrectFeedback

  // Congratulations screen for perfect score
  if (showCongratulations) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-purple-50 flex items-center justify-center">
        <div className="text-center max-w-2xl mx-auto p-8">
          <div className="mb-8">
            <div className="bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full p-8 inline-block shadow-2xl">
              <Trophy className="h-24 w-24 text-blue-900" />
            </div>
          </div>

          <h1 className="text-6xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent mb-6">
            Onnittelut! 🎉
          </h1>

          <div className="flex justify-center gap-2 mb-6">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="h-8 w-8 text-yellow-400 fill-current" />
            ))}
          </div>

          <p className="text-2xl text-gray-700 mb-8 leading-relaxed">
            Olet suorittanut kaikki moduulit täydellisesti!
            <br />
            <span className="text-green-600 font-semibold">100% kaikissa testeissä!</span>
          </p>

          <div className="bg-gradient-to-r from-green-100 to-blue-100 p-6 rounded-2xl mb-8 shadow-xl">
            <p className="text-lg text-gray-700">
              <strong>Erinomaista työtä!</strong> Hallitset nyt suomen kielen perusteet työpaikkaympäristössä.
            </p>
          </div>

          <Button
            asChild
            size="lg"
            className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white text-xl px-12 py-4 shadow-2xl font-bold"
          >
            <Link href="/learn-finnish">Takaisin oppimispolkuun</Link>
          </Button>
        </div>
      </div>
    )
  }

  // Regular completion screen
  if (quizCompleted) {
    const finalScore = score + (selectedAnswer === question.correctAnswer ? 1 : 0)
    const module4Percentage = Math.round((finalScore / questions.length) * 100)

    // Calculate overall score from all 4 modules
    const module1Score = 85
    const module2Score = 90
    const module3Score = 80
    const overallScore = Math.round((module1Score + module2Score + module3Score + module4Percentage) / 4)

    return (
      <div className="flex h-screen bg-gradient-to-br from-gray-50 to-blue-50">
        {/* Sidebar */}
        <div className="w-80 bg-gradient-to-b from-blue-900 to-blue-800 text-white p-8 flex flex-col shadow-2xl">
          <h2 className="text-2xl font-bold mb-8 flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full flex items-center justify-center">
              <span className="text-blue-900 font-bold">S</span>
            </div>
            Oppimispolku
          </h2>
          <ul className="space-y-6 flex-1">
            <li>
              <Link
                href="/modules/basic-vocabulary/intro"
                className="text-gray-300 text-lg block hover:text-white transition-colors flex items-center gap-2"
              >
                <CheckCircle className="h-5 w-5 text-green-400" />• Perussanasto
              </Link>
            </li>
            <li>
              <Link
                href="/modules/listening-comprehension/intro"
                className="text-gray-300 text-lg block hover:text-white transition-colors flex items-center gap-2"
              >
                <CheckCircle className="h-5 w-5 text-green-400" />• Kuullun ymmärtäminen
              </Link>
            </li>
            <li>
              <Link
                href="/modules/word-practice"
                className="text-gray-300 text-lg block hover:text-white transition-colors flex items-center gap-2"
              >
                <CheckCircle className="h-5 w-5 text-green-400" />• Sana- ja lauseharjoitukset
              </Link>
            </li>
            <li>
              <Link
                href="/modules/listening-quiz"
                className="text-yellow-300 font-semibold text-lg block hover:text-yellow-200 transition-colors flex items-center gap-2"
              >
                <Trophy className="h-5 w-5" />• Kuullun ymmärtämisen testi
              </Link>
            </li>
          </ul>

          <div className="flex gap-4 mt-8">
            <Button
              variant="outline"
              size="lg"
              asChild
              className="text-black bg-white border-2 border-white hover:bg-gray-100 hover:text-black flex-1 font-bold text-lg py-3 shadow-lg"
            >
              <Link href="/learn-finnish">
                <ArrowLeft className="h-5 w-5 mr-2" />
                Takaisin
              </Link>
            </Button>
          </div>
        </div>

        {/* Completion Screen */}
        <div className="flex-1 flex items-center justify-center p-8">
          <div className="max-w-4xl mx-auto text-center">
            <div className="bg-gradient-to-br from-white to-blue-50 rounded-3xl shadow-2xl p-12 border border-blue-200">
              <div className="mb-8">
                <div className="flex justify-center mb-6">
                  <div className="bg-gradient-to-r from-yellow-400 to-orange-400 p-4 rounded-full">
                    <Trophy className="h-24 w-24 text-blue-900" />
                  </div>
                </div>

                <div
                  className={`w-32 h-32 rounded-full mx-auto mb-6 flex items-center justify-center text-5xl font-bold text-white shadow-2xl ${
                    overallScore >= 80
                      ? "bg-gradient-to-br from-green-500 to-green-600"
                      : overallScore >= 60
                        ? "bg-gradient-to-br from-yellow-500 to-yellow-600"
                        : "bg-gradient-to-br from-red-500 to-red-600"
                  }`}
                >
                  {overallScore}%
                </div>

                <h1 className="text-5xl font-bold text-gray-800 mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Kaikki moduulit suoritettu!
                </h1>

                <p className="text-2xl text-gray-600 mb-8">
                  Kokonaispistemääräsi kaikista moduuleista on {overallScore}%
                </p>

                {/* Individual module scores */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
                  <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl shadow-lg border border-blue-200">
                    <div className="flex items-center justify-center mb-3">
                      <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                        <span className="text-white font-bold">📚</span>
                      </div>
                    </div>
                    <h3 className="font-bold text-blue-900 mb-2">Perussanasto</h3>
                    <p className="text-3xl font-bold text-blue-600 mb-1">85%</p>
                  </div>

                  <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-xl shadow-lg border border-green-200">
                    <div className="flex items-center justify-center mb-3">
                      <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                        <span className="text-white font-bold">🎧</span>
                      </div>
                    </div>
                    <h3 className="font-bold text-green-900 mb-2">Kuuntelu</h3>
                    <p className="text-3xl font-bold text-green-600 mb-1">90%</p>
                  </div>

                  <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-xl shadow-lg border border-purple-200">
                    <div className="flex items-center justify-center mb-3">
                      <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
                        <span className="text-white font-bold">✏️</span>
                      </div>
                    </div>
                    <h3 className="font-bold text-purple-900 mb-2">Harjoitukset</h3>
                    <p className="text-3xl font-bold text-purple-600 mb-1">80%</p>
                  </div>

                  <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-6 rounded-xl shadow-lg border border-orange-200">
                    <div className="flex items-center justify-center mb-3">
                      <div className="w-8 h-8 bg-orange-600 rounded-full flex items-center justify-center">
                        <span className="text-white font-bold">🎯</span>
                      </div>
                    </div>
                    <h3 className="font-bold text-orange-900 mb-2">Testi</h3>
                    <p className="text-3xl font-bold text-orange-600 mb-1">{module4Percentage}%</p>
                  </div>
                </div>

                {/* Motivational message */}
                <div className="bg-gradient-to-r from-blue-100 to-purple-100 p-6 rounded-xl mb-8 border border-blue-200">
                  {overallScore >= 80 && (
                    <p className="text-xl text-green-700 font-semibold flex items-center justify-center gap-3">
                      <Trophy className="h-6 w-6 text-yellow-500" />
                      Erinomaista työtä! Olet suorittanut kaikki moduulit erinomaisesti ja hallitset suomen kielen
                      perusteet!
                    </p>
                  )}
                  {overallScore >= 60 && overallScore < 80 && (
                    <p className="text-xl text-yellow-700 font-semibold flex items-center justify-center gap-3">
                      <Star className="h-6 w-6 text-yellow-500" />
                      Hyvää työtä! Olet suorittanut kaikki moduulit ja opit paljon suomea. Jatka harjoittelua!
                    </p>
                  )}
                  {overallScore < 60 && (
                    <p className="text-xl text-orange-700 font-semibold flex items-center justify-center gap-3">
                      <CheckCircle className="h-6 w-6 text-orange-500" />
                      Hyvä alku! Suosittelen kertaamaan moduuleja uudelleen. Harjoitus tekee mestarin!
                    </p>
                  )}
                </div>
              </div>

              <div className="flex gap-4 justify-center">
                <Button
                  asChild
                  size="lg"
                  className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white text-xl px-12 py-4 shadow-2xl font-bold"
                >
                  <Link href="/learn-finnish">Takaisin oppimispolkuun</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      {/* Sidebar */}
      <div className="w-80 bg-gradient-to-b from-blue-900 to-blue-800 text-white p-8 flex flex-col shadow-2xl">
        <h2 className="text-2xl font-bold mb-8 flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full flex items-center justify-center">
            <span className="text-blue-900 font-bold">S</span>
          </div>
          Oppimispolku
        </h2>
        <ul className="space-y-6 flex-1">
          <li>
            <Link
              href="/modules/basic-vocabulary/intro"
              className="text-gray-300 text-lg block hover:text-white transition-colors flex items-center gap-2"
            >
              <CheckCircle className="h-5 w-5 text-green-400" />• Perussanasto
            </Link>
            <div className="ml-6 mt-2 space-y-2">
              <Link
                href="/modules/basic-vocabulary/intro"
                className="text-gray-400 block hover:text-gray-200 transition-colors"
              >
                - Johdanto
              </Link>
              <Link
                href="/modules/basic-vocabulary"
                className="text-gray-400 block hover:text-gray-200 transition-colors"
              >
                - Harjoitus
              </Link>
            </div>
          </li>
          <li>
            <Link
              href="/modules/listening-comprehension/intro"
              className="text-gray-300 text-lg block hover:text-white transition-colors flex items-center gap-2"
            >
              <CheckCircle className="h-5 w-5 text-green-400" />• Kuullun ymmärtäminen
            </Link>
            <div className="ml-6 mt-2 space-y-2">
              <Link
                href="/modules/listening-comprehension/intro"
                className="text-gray-400 block hover:text-gray-200 transition-colors"
              >
                - Johdanto
              </Link>
              <Link
                href="/modules/listening-comprehension"
                className="text-gray-400 block hover:text-gray-200 transition-colors"
              >
                - Harjoitus
              </Link>
            </div>
          </li>
          <li>
            <Link
              href="/modules/word-practice"
              className="text-gray-300 text-lg block hover:text-white transition-colors flex items-center gap-2"
            >
              <CheckCircle className="h-5 w-5 text-green-400" />• Sana- ja lauseharjoitukset
            </Link>
            <div className="ml-6 mt-2 space-y-2">
              <Link href="/modules/word-practice" className="text-gray-400 block hover:text-gray-200 transition-colors">
                - Harjoitus A
              </Link>
              <Link href="/modules/word-practice" className="text-gray-400 block hover:text-gray-200 transition-colors">
                - Harjoitus B
              </Link>
              <Link href="/modules/word-practice" className="text-gray-400 block hover:text-gray-200 transition-colors">
                - Harjoitus C
              </Link>
            </div>
          </li>
          <li>
            <Link
              href="/modules/listening-quiz"
              className="text-yellow-300 font-semibold text-lg block hover:text-yellow-200 transition-colors flex items-center gap-2"
            >
              <Trophy className="h-5 w-5" />• Kuullun ymmärtämisen testi
            </Link>
          </li>
        </ul>

        <div className="flex gap-4 mt-8">
          <Button
            variant="outline"
            size="lg"
            asChild
            className="text-black bg-white border-2 border-white hover:bg-gray-100 hover:text-black flex-1 font-bold text-lg py-3 shadow-lg"
          >
            <Link href="/modules/word-practice">
              <ArrowLeft className="h-5 w-5 mr-2" />
              Takaisin
            </Link>
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        <div className="bg-gradient-to-r from-blue-900 to-blue-800 text-white p-8 shadow-lg">
          <div className="bg-blue-800 p-6 rounded-lg shadow-inner">
            <h2 className="text-4xl font-bold mb-3 flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full flex items-center justify-center shadow-lg">
                <span className="text-blue-900 font-bold text-xl">🎯</span>
              </div>
              Kuullun ymmärtämisen testi
            </h2>
            <p className="text-blue-100 text-xl">Katso kuvaa, kuuntele ja klikkaa, onko lause oikein vai väärin.</p>
          </div>
        </div>

        <div className="flex-1 p-8 overflow-auto">
          <div className="max-w-6xl mx-auto">
            {/* Image */}
            <div className="relative mb-8">
              <Image
                src="/images/modula4.jpg"
                alt="Kahvilakuva testiä varten"
                width={1200}
                height={675}
                className="w-full rounded-xl shadow-2xl border border-gray-200"
              />
              <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm px-4 py-2 rounded-full text-lg font-medium shadow-lg border border-gray-200">
                Kysymys {currentQuestion + 1} / {questions.length}
              </div>
            </div>

            {/* Quiz content */}
            <div className="space-y-8 max-w-4xl mx-auto">
              {/* Question */}
              <div className="bg-gradient-to-r from-blue-100 to-blue-200 p-8 rounded-xl shadow-lg flex items-center gap-6 border border-blue-300">
                <button
                  onClick={playAudio}
                  className="bg-gradient-to-br from-blue-600 to-blue-700 text-white p-6 rounded-full hover:from-blue-700 hover:to-blue-800 transition-all duration-300 shadow-lg flex-shrink-0"
                  disabled={isPlaying}
                >
                  <Play className="h-8 w-8" />
                </button>
                <p className="text-2xl font-medium text-gray-800">{question.statement}</p>
              </div>

              {/* Answer buttons - More visible */}
              {!showFeedback && (
                <div className="flex gap-6 justify-center">
                  <Button
                    onClick={() => handleAnswerSelect(true)}
                    size="lg"
                    className="bg-gradient-to-r from-teal-600 to-teal-700 hover:from-teal-700 hover:to-teal-800 text-white text-3xl px-20 py-8 rounded-xl shadow-2xl font-bold"
                  >
                    oikein
                  </Button>
                  <Button
                    onClick={() => handleAnswerSelect(false)}
                    size="lg"
                    className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white text-3xl px-20 py-8 rounded-xl shadow-2xl font-bold"
                  >
                    väärin
                  </Button>
                </div>
              )}

              {/* Feedback */}
              {showFeedback && (
                <div className="space-y-8">
                  {/* Show selected answer */}
                  <div className="flex gap-6 justify-center">
                    <Button
                      disabled
                      size="lg"
                      className={`text-3xl px-20 py-8 rounded-xl shadow-2xl font-bold ${
                        selectedAnswer === true
                          ? isCorrectAnswer
                            ? "bg-gradient-to-r from-green-600 to-green-700 text-white"
                            : "bg-gradient-to-r from-red-600 to-red-700 text-white"
                          : "bg-gray-300 text-gray-500"
                      }`}
                    >
                      oikein
                    </Button>
                    <Button
                      disabled
                      size="lg"
                      className={`text-3xl px-20 py-8 rounded-xl shadow-2xl font-bold ${
                        selectedAnswer === false
                          ? isCorrectAnswer
                            ? "bg-gradient-to-r from-green-600 to-green-700 text-white"
                            : "bg-gradient-to-r from-red-600 to-red-700 text-white"
                          : "bg-gray-300 text-gray-500"
                      }`}
                    >
                      väärin
                    </Button>
                  </div>

                  {/* Feedback message */}
                  <div
                    className={`p-8 rounded-xl shadow-lg border-l-4 ${
                      isCorrectAnswer
                        ? "bg-gradient-to-r from-green-50 to-green-100 text-green-800 border-green-500"
                        : "bg-gradient-to-r from-red-50 to-red-100 text-red-800 border-red-500"
                    }`}
                  >
                    <div className="flex items-start gap-4">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg ${
                          isCorrectAnswer ? "bg-green-500" : "bg-red-500"
                        }`}
                      >
                        {isCorrectAnswer ? "✓" : "✗"}
                      </div>
                      <p className="text-2xl leading-relaxed">{feedbackText}</p>
                    </div>
                  </div>

                  {/* Next question button - More visible */}
                  <div className="flex justify-center">
                    <Button
                      onClick={handleNextQuestion}
                      size="lg"
                      className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white text-2xl px-16 py-6 shadow-2xl font-bold"
                    >
                      {currentQuestion < questions.length - 1 ? "Seuraava kysymys" : "Lopeta testi"}
                    </Button>
                  </div>
                </div>
              )}

              {/* Progress indicator */}
              <div className="bg-gradient-to-r from-white to-blue-50 p-6 rounded-lg shadow-lg border border-blue-200">
                <div className="flex justify-between items-center mb-3">
                  <span className="text-lg font-medium text-gray-600">Edistyminen</span>
                  <span className="text-lg font-medium text-gray-600">
                    {currentQuestion + 1} / {questions.length}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3 shadow-inner">
                  <div
                    className="bg-gradient-to-r from-blue-600 to-blue-700 h-3 rounded-full transition-all duration-300 shadow-sm"
                    style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
