"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import {
  Play,
  Volume2,
  HelpCircle,
  ArrowLeft,
  ArrowRight,
  RotateCcw,
  CheckCircle,
  XCircle,
  Trophy,
  Star,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

// Define the vocabulary items with new images - will be randomized
const baseVocabularyItems = [
  {
    id: 1,
    word: "kahviautomaatti",
    english: "coffee machine",
    image: "/images/coffee-machine-new.jpg",
  },
  {
    id: 2,
    word: "juomalasit",
    english: "drinking glasses",
    image: "/images/glass-new.jpg",
  },
  {
    id: 3,
    word: "hunaja",
    english: "honey",
    image: "/images/honey-new.jpg",
  },
  {
    id: 4,
    word: "vedenkeitin",
    english: "water kettle",
    image: "/images/kettle-new.jpg",
  },
  {
    id: 5,
    word: "kakkupalat",
    english: "cake pieces",
    image: "/images/cake-new.png",
  },
  {
    id: 6,
    word: "sokeri",
    english: "sugar",
    image: "/images/sugar-new.jpg",
  },
  {
    id: 7,
    word: "teepussit",
    english: "tea bags",
    image: "/images/tea-new.jpg",
  },
  {
    id: 8,
    word: "makeutusaine",
    english: "sweetener",
    image: "/images/sugar-free-new.jpg",
  },
  {
    id: 9,
    word: "kahvitermos",
    english: "coffee thermos",
    image: "/images/coffee-new.jpg",
  },
]

// Shuffle function
const shuffleArray = (array: any[]) => {
  const shuffled = [...array]
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]]
  }
  return shuffled
}

export default function BasicVocabulary() {
  const [vocabularyItems, setVocabularyItems] = useState(baseVocabularyItems)
  const [isPlaying, setIsPlaying] = useState<number | null>(null)
  const [matches, setMatches] = useState<{ [key: number]: number }>({})
  const [feedback, setFeedback] = useState<string | null>(null)
  const [selectedAudio, setSelectedAudio] = useState<number | null>(null)
  const [showResults, setShowResults] = useState(false)
  const [correctAnswers, setCorrectAnswers] = useState<Set<number>>(new Set())
  const [showCongratulations, setShowCongratulations] = useState(false)

  // Randomize items on component mount
  useEffect(() => {
    setVocabularyItems(shuffleArray(baseVocabularyItems))
  }, [])

  // AI Voice synthesis function
  const speakFinnish = (text: string, audioIndex: number) => {
    setIsPlaying(audioIndex)
    if (audioIndex >= 0) {
      setSelectedAudio(audioIndex)
    }

    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = "fi-FI"
      utterance.rate = 0.7
      utterance.pitch = 1

      utterance.onend = () => {
        setIsPlaying(null)
      }

      speechSynthesis.speak(utterance)
    }
  }

  const handleImageClick = (imageId: number) => {
    if (selectedAudio !== null) {
      setMatches((prev) => ({ ...prev, [selectedAudio]: imageId }))

      // Check if correct match
      if (selectedAudio === imageId - 1) {
        setCorrectAnswers((prev) => new Set([...prev, selectedAudio]))
        setFeedback("Oikein! Hyvä!")
        speakFinnish("Oikein! Hyvä!", -1)
      } else {
        setFeedback("Väärin. Yritä uudelleen!")
        speakFinnish("Väärin. Yritä uudelleen!", -1)
      }

      setTimeout(() => {
        setFeedback(null)
        setSelectedAudio(null)
      }, 2000)
    } else {
      setFeedback("Klikkaa ensin ääninappulaa! Kuuntele sana ensin!")
      setTimeout(() => setFeedback(null), 2000)
    }
  }

  const checkAllAnswers = () => {
    setShowResults(true)
    const correctCount = correctAnswers.size
    const percentage = Math.round((correctCount / vocabularyItems.length) * 100)

    if (correctCount === vocabularyItems.length) {
      setShowCongratulations(true)
      speakFinnish("Onnittelut! Kaikki vastaukset ovat oikein! Voit siirtyä seuraavaan moduuliin!", -1)
    } else {
      speakFinnish(`${percentage} prosenttia oikein`, -1)
    }
  }

  const resetExercise = () => {
    setMatches({})
    setShowResults(false)
    setSelectedAudio(null)
    setFeedback(null)
    setCorrectAnswers(new Set())
    setShowCongratulations(false)
    // Randomize again on reset
    setVocabularyItems(shuffleArray(baseVocabularyItems))
  }

  if (showCongratulations) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-purple-50 flex items-center justify-center">
        <div className="text-center max-w-2xl mx-auto p-8">
          <div className="mb-8">
            <div className="bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full p-8 inline-block shadow-2xl">
              <Trophy className="h-24 w-24 text-blue-900" />
            </div>
          </div>

          <h1 className="text-6xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent mb-6">
            Onnittelut! 🎉
          </h1>

          <div className="flex justify-center gap-2 mb-6">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="h-8 w-8 text-yellow-400 fill-current" />
            ))}
          </div>

          <p className="text-2xl text-gray-700 mb-8 leading-relaxed">
            Olet suorittanut perussanaston moduulin täydellisesti!
            <br />
            <span className="text-green-600 font-semibold">100% oikein!</span>
          </p>

          <div className="bg-gradient-to-r from-green-100 to-blue-100 p-6 rounded-2xl mb-8 shadow-xl">
            <p className="text-lg text-gray-700">
              Olet nyt valmis siirtymään seuraavaan moduuliin: <strong>Kuullun ymmärtäminen</strong>
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="lg"
              className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white text-xl px-12 py-4 shadow-2xl font-bold"
            >
              <Link href="/modules/listening-comprehension/intro" className="flex items-center gap-3">
                <ArrowRight className="h-6 w-6" />
                Seuraava moduuli
              </Link>
            </Button>

            <Button
              onClick={resetExercise}
              variant="outline"
              size="lg"
              className="text-xl px-12 py-4 border-2 border-blue-500 text-blue-600 hover:bg-blue-50 font-bold"
            >
              <RotateCcw className="h-6 w-6 mr-2" />
              Harjoittele uudelleen
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Sidebar */}
      <div className="w-80 bg-gradient-to-b from-blue-900 via-blue-800 to-purple-900 text-white p-8 flex flex-col shadow-2xl">
        <h2 className="text-2xl font-bold mb-8 flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full flex items-center justify-center shadow-lg">
            <span className="text-blue-900 font-bold">S</span>
          </div>
          Oppimispolku
        </h2>
        <ul className="space-y-6 flex-1">
          <li>
            <Link
              href="/modules/basic-vocabulary/intro"
              className="text-yellow-300 font-semibold text-lg block hover:text-yellow-200 transition-colors flex items-center gap-2"
            >
              <CheckCircle className="h-5 w-5" />• Perussanasto
            </Link>
            <div className="ml-6 mt-2 space-y-2">
              <Link
                href="/modules/basic-vocabulary/intro"
                className="text-gray-400 block hover:text-gray-200 transition-colors"
              >
                - Johdanto
              </Link>
              <Link
                href="/modules/basic-vocabulary"
                className="text-yellow-200 block hover:text-yellow-100 transition-colors"
              >
                - Harjoitus
              </Link>
            </div>
          </li>
          <li>
            <Link
              href="/modules/listening-comprehension/intro"
              className="text-gray-300 text-lg block hover:text-white transition-colors"
            >
              • Kuullun ymmärtäminen
            </Link>
            <div className="ml-6 mt-2 space-y-2">
              <Link
                href="/modules/listening-comprehension/intro"
                className="text-gray-400 block hover:text-gray-200 transition-colors"
              >
                - Johdanto
              </Link>
              <Link
                href="/modules/listening-comprehension"
                className="text-gray-400 block hover:text-gray-200 transition-colors"
              >
                - Harjoitus
              </Link>
            </div>
          </li>
          <li>
            <Link
              href="/modules/word-practice"
              className="text-gray-300 text-lg block hover:text-white transition-colors"
            >
              • Sana- ja lauseharjoitukset
            </Link>
            <div className="ml-6 mt-2 space-y-2">
              <Link href="/modules/word-practice" className="text-gray-400 block hover:text-gray-200 transition-colors">
                - Harjoitus A
              </Link>
              <Link href="/modules/word-practice" className="text-gray-400 block hover:text-gray-200 transition-colors">
                - Harjoitus B
              </Link>
              <Link href="/modules/word-practice" className="text-gray-400 block hover:text-gray-200 transition-colors">
                - Harjoitus C
              </Link>
            </div>
          </li>
          <li>
            <Link
              href="/modules/listening-quiz"
              className="text-gray-300 text-lg block hover:text-white transition-colors"
            >
              • Kuullun ymmärtämisen testi
            </Link>
          </li>
        </ul>

        <div className="flex gap-3 mt-8">
          <Button
            variant="outline"
            size="lg"
            asChild
            className="text-black bg-white border-2 border-white hover:bg-gray-100 hover:text-black flex-1 font-bold text-lg py-3 shadow-lg"
          >
            <Link href="/modules/basic-vocabulary/intro">
              <ArrowLeft className="h-5 w-5 mr-2" />
              Takaisin
            </Link>
          </Button>
          <Button
            variant="outline"
            size="lg"
            asChild
            className="text-black bg-white border-2 border-white hover:bg-gray-100 hover:text-black flex-1 font-bold text-lg py-3 shadow-lg"
          >
            <Link href="/modules/listening-comprehension/intro">
              <ArrowRight className="h-5 w-5 mr-2" />
              Seuraava
            </Link>
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-purple-900 text-white p-8 shadow-lg">
          <div className="bg-gradient-to-r from-blue-800 to-purple-800 p-6 rounded-lg shadow-inner">
            <h2 className="text-4xl font-bold mb-3 flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full flex items-center justify-center shadow-lg">
                <span className="text-blue-900 font-bold text-xl">📚</span>
              </div>
              Perussanasto
            </h2>
            <p className="text-blue-100 text-xl">Klikkaa puhekuplaa ja kuuntele sana. Yhdistä sana oikeaan kuvaan.</p>
          </div>
        </div>

        <div className="flex-1 p-8 overflow-auto">
          {/* Audio buttons */}
          <div className="grid grid-cols-5 gap-6 mb-12">
            {vocabularyItems.map((item, index) => (
              <div
                key={item.id}
                className={`p-6 rounded-xl flex items-center justify-center gap-3 cursor-pointer transition-all duration-300 shadow-lg hover:shadow-xl ${
                  correctAnswers.has(index)
                    ? "bg-gradient-to-br from-green-200 to-green-300 border-2 border-green-500"
                    : selectedAudio === index
                      ? "bg-gradient-to-br from-blue-200 to-blue-300 border-2 border-blue-500 shadow-xl"
                      : isPlaying === index
                        ? "bg-gradient-to-br from-blue-150 to-blue-200 border border-blue-300"
                        : "bg-gradient-to-br from-blue-100 to-blue-150 hover:from-blue-150 hover:to-blue-200 border border-transparent hover:border-blue-300"
                }`}
              >
                <button
                  onClick={() => speakFinnish(item.word, index)}
                  className={`text-white p-4 rounded-full hover:opacity-90 transition-all duration-300 shadow-lg ${
                    correctAnswers.has(index)
                      ? "bg-gradient-to-br from-green-600 to-green-700"
                      : "bg-gradient-to-br from-blue-600 to-blue-700"
                  }`}
                  disabled={isPlaying === index}
                >
                  <Play className="h-6 w-6" />
                </button>
                <Volume2 className={`h-6 w-6 ${correctAnswers.has(index) ? "text-green-600" : "text-blue-600"}`} />
                <HelpCircle className={`h-6 w-6 ${correctAnswers.has(index) ? "text-green-600" : "text-blue-600"}`} />
              </div>
            ))}
          </div>

          {/* Images with INCREASED HEIGHT and proper scaling */}
          <div className="grid grid-cols-3 gap-8 mb-12">
            {vocabularyItems.map((item) => {
              const isMatched = Object.values(matches).includes(item.id)
              const matchedAudioIndex = Object.entries(matches).find(([_, imageId]) => imageId === item.id)?.[0]
              const isCorrect = matchedAudioIndex ? correctAnswers.has(Number.parseInt(matchedAudioIndex)) : false

              return (
                <div
                  key={item.id}
                  className={`border-2 rounded-xl overflow-hidden cursor-pointer transition-all duration-300 shadow-lg hover:shadow-2xl hover:scale-105 ${
                    isCorrect
                      ? "border-green-500 bg-gradient-to-b from-green-50 to-green-100 shadow-green-200"
                      : isMatched && showResults
                        ? "border-red-500 bg-gradient-to-b from-red-50 to-red-100 shadow-red-200"
                        : isMatched
                          ? "border-blue-500 bg-gradient-to-b from-blue-50 to-blue-100 shadow-blue-200"
                          : "border-gray-200 hover:border-blue-300 hover:shadow-blue-100 bg-white"
                  }`}
                  onClick={() => handleImageClick(item.id)}
                >
                  <div className="relative">
                    <Image
                      src={item.image || "/placeholder.svg"}
                      alt={item.word}
                      width={400}
                      height={350}
                      className="w-full h-96 object-cover"
                    />
                    {isCorrect && (
                      <div className="absolute top-4 right-4 w-12 h-12 rounded-full flex items-center justify-center text-white font-bold bg-gradient-to-br from-green-500 to-green-600 text-2xl shadow-lg">
                        ✓
                      </div>
                    )}
                    {isMatched && !isCorrect && showResults && (
                      <div className="absolute top-4 right-4 w-12 h-12 rounded-full flex items-center justify-center text-white font-bold bg-gradient-to-br from-red-500 to-red-600 text-2xl shadow-lg">
                        ✗
                      </div>
                    )}
                  </div>

                  {/* Show word below image when correct or when showing results */}
                  {(isCorrect || (showResults && isMatched)) && (
                    <div
                      className={`text-white text-center py-4 font-bold text-xl shadow-inner ${
                        isCorrect
                          ? "bg-gradient-to-r from-green-500 to-green-600"
                          : "bg-gradient-to-r from-red-500 to-red-600"
                      }`}
                    >
                      {item.word}
                    </div>
                  )}
                </div>
              )
            })}
          </div>

          {/* Action Buttons - More visible */}
          <div className="flex justify-center gap-6 mb-8">
            {!showResults ? (
              <Button
                onClick={checkAllAnswers}
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white text-2xl px-16 py-6 shadow-2xl font-bold"
                disabled={correctAnswers.size === 0}
              >
                Tarkista vastaukset
              </Button>
            ) : (
              <Button
                onClick={resetExercise}
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white text-2xl px-16 py-6 flex items-center gap-3 shadow-2xl font-bold"
              >
                <RotateCcw className="h-6 w-6" />
                Yritä uudelleen
              </Button>
            )}
          </div>

          {/* Feedback */}
          {feedback && (
            <div
              className={`p-6 rounded-xl text-center font-medium text-xl mb-8 shadow-lg ${
                feedback.includes("Oikein")
                  ? "bg-gradient-to-r from-green-100 to-green-200 text-green-800 border-2 border-green-300"
                  : "bg-gradient-to-r from-red-100 to-red-200 text-red-800 border-2 border-red-300"
              }`}
            >
              <div className="flex items-center justify-center gap-3">
                {feedback.includes("Oikein") ? (
                  <CheckCircle className="h-8 w-8 text-green-600" />
                ) : (
                  <XCircle className="h-8 w-8 text-red-600" />
                )}
                {feedback}
              </div>
            </div>
          )}

          {/* Results Summary */}
          {showResults && (
            <div className="bg-gradient-to-br from-white via-blue-50 to-purple-50 p-8 rounded-xl shadow-2xl mb-8 border border-blue-200">
              <h3 className="text-2xl font-bold text-center mb-6 flex items-center justify-center gap-3">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                  <CheckCircle className="h-5 w-5 text-white" />
                </div>
                Tulokset
              </h3>
              <div className="text-center">
                <div className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4 drop-shadow-lg">
                  {Math.round((correctAnswers.size / vocabularyItems.length) * 100)}%
                </div>
                <p className="text-gray-600 text-xl">Oikeita yhdistämisiä</p>
                <div className="mt-4 text-lg text-gray-700">
                  {correctAnswers.size} / {vocabularyItems.length} oikein
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
