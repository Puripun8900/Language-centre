import Link from "next/link"
import Image from "next/image"
import { Book, Headphones, MessageSquare, CheckSquare } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function LearningPath() {
  return (
    <div className="w-full min-h-screen bg-white">
      <div className="relative w-full h-full">
        <Image src="/images/cafe-background.jpg" alt="Café background" fill className="object-cover opacity-20 z-0" />

        <div className="relative z-10 container mx-auto px-4 py-12">
          <h1 className="text-3xl font-bold border-b-2 border-yellow-400 pb-2 mb-8">Learning Path</h1>

          <div className="grid gap-16">
            {/* Basic Vocabulary */}
            <div className="grid md:grid-cols-[1fr_auto_1fr] gap-8 items-center">
              <div>
                <h2 className="text-2xl font-bold text-blue-900">Basic Vocabulary</h2>
                <p className="text-gray-700 mt-2">Learn essential Finnish vocabulary for the workplace break room.</p>
                <Button asChild className="mt-4">
                  <Link href="/modules/basic-vocabulary">Start Learning</Link>
                </Button>
              </div>

              <div className="flex justify-center">
                <div className="bg-blue-600 rounded-full p-4 text-white">
                  <Book size={32} />
                </div>
              </div>

              <div className="bg-blue-50 p-6 rounded-lg">
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <span className="bg-blue-100 w-2 h-2 rounded-full"></span>
                    Learn 9 essential café vocabulary words
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="bg-blue-100 w-2 h-2 rounded-full"></span>
                    Practice pronunciation with audio
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="bg-blue-100 w-2 h-2 rounded-full"></span>
                    Match words to images
                  </li>
                </ul>
              </div>
            </div>

            {/* Listening Comprehension */}
            <div className="grid md:grid-cols-[1fr_auto_1fr] gap-8 items-center">
              <div>
                <h2 className="text-2xl font-bold text-blue-900">Listening Comprehension</h2>
                <p className="text-gray-700 mt-2">Practice understanding spoken Finnish in a café environment.</p>
                <Button asChild className="mt-4">
                  <Link href="/modules/listening-comprehension">Start Learning</Link>
                </Button>
              </div>

              <div className="flex justify-center">
                <div className="bg-blue-600 rounded-full p-4 text-white">
                  <Headphones size={32} />
                </div>
              </div>

              <div className="bg-blue-50 p-6 rounded-lg">
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <span className="bg-blue-100 w-2 h-2 rounded-full"></span>
                    Listen to instructions in Finnish
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="bg-blue-100 w-2 h-2 rounded-full"></span>
                    Identify objects in a café scene
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="bg-blue-100 w-2 h-2 rounded-full"></span>
                    Improve your listening comprehension
                  </li>
                </ul>
              </div>
            </div>

            {/* Word and Sentence Practice */}
            <div className="grid md:grid-cols-[1fr_auto_1fr] gap-8 items-center">
              <div>
                <h2 className="text-2xl font-bold text-blue-900">Word and Sentence Practice</h2>
                <p className="text-gray-700 mt-2">Practice forming Finnish sentences and using verbs correctly.</p>
                <Button asChild className="mt-4">
                  <Link href="/modules/word-practice">Start Learning</Link>
                </Button>
              </div>

              <div className="flex justify-center">
                <div className="bg-blue-600 rounded-full p-4 text-white">
                  <MessageSquare size={32} />
                </div>
              </div>

              <div className="bg-blue-50 p-6 rounded-lg">
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <span className="bg-blue-100 w-2 h-2 rounded-full"></span>
                    Match sentence beginnings and endings
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="bg-blue-100 w-2 h-2 rounded-full"></span>
                    Learn common Finnish verbs
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="bg-blue-100 w-2 h-2 rounded-full"></span>
                    Practice using verbs in context
                  </li>
                </ul>
              </div>
            </div>

            {/* Listening Comprehension Quiz */}
            <div className="grid md:grid-cols-[1fr_auto_1fr] gap-8 items-center">
              <div>
                <h2 className="text-2xl font-bold text-blue-900">Listening Comprehension Quiz</h2>
                <p className="text-gray-700 mt-2">Test your Finnish comprehension with a true/false quiz.</p>
                <Button asChild className="mt-4">
                  <Link href="/modules/listening-quiz">Start Learning</Link>
                </Button>
              </div>

              <div className="flex justify-center">
                <div className="bg-blue-600 rounded-full p-4 text-white">
                  <CheckSquare size={32} />
                </div>
              </div>

              <div className="bg-blue-50 p-6 rounded-lg">
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <span className="bg-blue-100 w-2 h-2 rounded-full"></span>
                    Listen to descriptions in Finnish
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="bg-blue-100 w-2 h-2 rounded-full"></span>
                    Determine if statements are true or false
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="bg-blue-100 w-2 h-2 rounded-full"></span>
                    Test your overall comprehension
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
